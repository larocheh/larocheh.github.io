% Version 1.000
%
% Code provided by Hugo Larochelle and Ruslan Salakhutdinov
%
% Permission is granted for anyone to copy, use, modify, or distribute this
% program and accompanying programs and documents for any purpose, provided
% this copyright notice is retained and prominently displayed, along with
% a note saying that the original programs are available from our
% web page.
% The programs and documents are distributed without any warranty, express or
% implied.  As the programs were written for research purposes only, they have
% not been tested to the degree that would be advisable in any important
% application.  All use of these programs is entirely at the user's own risk.

warning off

if ~exist('dbm_numhid','var')
  dbm_numhid = 500;
end
if ~exist('dbm_numpen','var')
  dbm_numpen = 1000;
end

close all

if ~exist('dataset','var') || strcmp(dataset,'mnist')
  if ~exist('digit9.mat','file')
    mnistconverter;
  end
  mnistmakebatches;
elseif strcmp(dataset,'ocr-letter')
  one_hot_targets = eye(26,26);
  
  train = load('letter_train.amat');
  train_input = train(:,1:(end-1));
  train_target = one_hot_targets(train(:,end)+1,:);
  [batchdata batchtargets] = make_batches(train_input, train_target,100);
  
  valid = load('letter_valid.amat');
  valid_input = valid(:,1:(end-1));
  valid_target = one_hot_targets(valid(:,end)+1,:);
  [validbatchdata validbatchtargets] = make_batches(valid_input, valid_target,100);
  
  test = load('letter_test.amat');
  test_input = test(:,1:(end-1));
  test_target = one_hot_targets(test(:,end)+1,:);
  [testbatchdata testbatchtargets] = make_batches(test_input, test_target,100);
else
  % Add your own dataset here!
  %
  % Just need to create variables the following variables:
  % - batchdata and batchtargets (training set)
  % - validbatchdata and validbatchtargets (validation set)
  % - testbatchdata and testbatchtargets (test set)
  error('No dataset was loaded...');
end

randn('state',100);
rand('state',100);
fprintf(1,'Pretraining a Deep Boltzmann Machine. \n');

[numcases numdims numbatches]=size(batchdata);

%%%%%% Training 1st layer %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numhid=dbm_numhid;
maxepoch=100;
fprintf(1,'Pretraining Layer 1 with RBM: %d-%d \n',numdims,numhid);
restart=1;
tic;
rbm
rbm_toc = toc;
fprintf('Pretraining Layer 1 took %f seconds\n',rbm_toc);

%%%%%% Training 2st layer %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all 
numpen = dbm_numpen; 
maxepoch=100;
fprintf(1,'\nPretraining Layer 2 with RBM: %d-%d \n',numhid,numpen);
restart=1;
tic;
rbm_l2
rbm_l2_toc = toc;
fprintf('Pretraining Layer 2 took %f seconds\n',rbm_l2_toc);
%%%%%% Training two-layer Boltzmann machine %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all 
randn('state',100);
rand('state',100);
numhid=dbm_numhid; 
numpen=dbm_numpen; 
if ~exist('maxit', 'var')
  maxit=1;
end
if ~exist('use_cg','var')
  use_cg=0.01;
end
maxit
use_cg
maxepoch=200; 

fprintf(1,'Learning a Deep Bolztmann Machine with recognition network. \n');
restart=1;
dbm_mf_pred

%%%%%% Fine-tuning two-layer Boltzmann machine  for classification %%%%%%%%%%%%%%%%%
maxepoch=100;
tic;
backprop_mf_pred
backprop_toc = toc;
fprintf('Fine-tuning with backprop took %f seconds\n',backprop_toc);

