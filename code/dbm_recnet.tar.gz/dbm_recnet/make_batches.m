% Version 1.000
%
% Code provided by Hugo Larochelle and Ruslan Salakhutdinov
%
% Permission is granted for anyone to copy, use, modify, or distribute this
% program and accompanying programs and documents for any purpose, provided
% this copyright notice is retained and prominently displayed, along with
% a note saying that the original programs are available from our
% web page.
% The programs and documents are distributed without any warranty, express or
% implied.  As the programs were written for research purposes only, they have
% not been tested to the degree that would be advisable in any important
% application.  All use of these programs is entirely at the user's own risk.

function [batchdata batchtargets] = make_batches(nobatchdata, ...
						 nobatchtargets, ...
						 batchsize)

[n d] = size(nobatchdata);
[n l] = size(nobatchtargets);

if mod(n,batchsize) ~= 0
  fprintf(['Warning: %d examples do not fit exactly in %d mini-batches, so\n' ...
	   'the first examples will be used to fill last batch.\n'], ...
	  n, batchsize)
end

batchdata = zeros(batchsize,d,ceil(n/batchsize));
batchtargets = zeros(batchsize,l,ceil(n/batchsize));

k = 1;
for i=1:ceil(n/batchsize)
  for j=1:batchsize
    if k > n
      k = 1;
    end
    batchdata(j,:,i) = nobatchdata(k,:);
    batchtargets(j,:,i) = nobatchtargets(k,:);
    k=k+1;
  end
end
