% Version 1.000
%
% Code provided by Hugo Larochelle and Ruslan Salakhutdinov
%
% Permission is granted for anyone to copy, use, modify, or distribute this
% program and accompanying programs and documents for any purpose, provided
% this copyright notice is retained and prominently displayed, along with
% a note saying that the original programs are available from our
% web page.
% The programs and documents are distributed without any warranty, express or
% implied.  As the programs were written for research purposes only, they have
% not been tested to the degree that would be advisable in any important
% application.  All use of these programs is entirely at the user's own risk.

lambda=0; 
[dummy numlab dummy]=size(batchtargets);

if exist('validbatchdata','var')
  valid_err=[];
  valid_crerr=[];
end
test_err=[];
test_crerr=[];
train_err=[];
train_crerr=[];

fprintf(1,'\nTraining discriminative model by minimizing cross entropy error. \n');
fprintf(1,'With CG and batches 100 times bigger. \n');

[numcases numdims numbatches]=size(batchdata);
N=numcases; 

load full_dbm
[numdims numhids] = size(vishid);
[numhids numpens] = size(hidpen); 

load mf_predictor

%%%%%% Preprocess the data %%%%%%%%%%%%%%%%%%%%%%

if exist('validbatchdata','var')
  [validnumcases validnumdims validnumbatches]=size(validbatchdata);
  N=validnumcases;
  temp_h2_valid = zeros(validnumcases,numpens,validnumbatches); 
  for batch = 1:validnumbatches
    data = [validbatchdata(:,:,batch)];
    mf_prediction;
    [temp_h1, temp_h2, tot_it] = ...
	mf_class_init(data,vishid,hidbiases,visbiases,hidpen,penbiases,init_h1,init_h2,maxit);
    temp_h2_valid(:,:,batch) = temp_h2;
  end    
end

[testnumcases testnumdims testnumbatches]=size(testbatchdata);
N=testnumcases;
temp_h2_test = zeros(testnumcases,numpens,testnumbatches); 
for batch = 1:testnumbatches
  data = [testbatchdata(:,:,batch)];
  mf_prediction;
  [temp_h1, temp_h2, tot_it] = ...
      mf_class_init(data,vishid,hidbiases,visbiases,hidpen,penbiases,init_h1,init_h2,maxit);
  temp_h2_test(:,:,batch) = temp_h2;
end  

[numcases numdims numbatches]=size(batchdata);
N=numcases;
temp_h2_train = zeros(numcases,numpens,numbatches);
for batch = 1:numbatches
  data = [batchdata(:,:,batch)];
  mf_prediction;
  [temp_h1, temp_h2, tot_it] = ...
      mf_class_init(data,vishid,hidbiases,visbiases,hidpen,penbiases,init_h1,init_h2,maxit);
  temp_h2_train(:,:,batch) = temp_h2;
end

%%%%%%%%%%%%%% Done %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

w1_penhid = hidpen';
w1_vishid = vishid;
w2 = hidpen;
h1_biases = hidbiases; h2_biases = penbiases; 

w_class = 0.1*randn(numpens,numlab); 
topbiases = 0.1*randn(1,numlab);

for epoch = 1:maxepoch 

  if exist('validbatchdata','var')
    %%%% VALID STATS 
    %%%% Error rates 
    [validnumcases validnumdims validnumbatches]=size(validbatchdata);
    N=validnumcases;
    bias_hid= repmat(h1_biases,N,1);
    bias_pen = repmat(h2_biases,N,1);
    bias_top = repmat(topbiases,N,1);
    
    err=0;
    err_cr=0;
    counter=0;  
    for batch = 1:validnumbatches
      data = [validbatchdata(:,:,batch)];
      temp_h2 = temp_h2_valid(:,:,batch); 
      target = [validbatchtargets(:,:,batch)]; 
      
      w1probs = 1./(1 + exp(-data*w1_vishid -temp_h2*w1_penhid - bias_hid  )); 
      w2probs = 1./(1 + exp(-w1probs*w2 - bias_pen)); 
      targetout = exp(w2probs*w_class + bias_top );
      targetout = targetout./repmat(sum(targetout,2),1,numlab);
      [I J]=max(targetout,[],2); 
      [I1 J1]=max(target,[],2); 
      counter=counter+length(find(J~=J1));  
      
      err_cr = err_cr- sum(sum( target(:,1:end).*log(targetout))) ;
      
    end
    valid_err(epoch)=counter;
    valid_crerr(epoch)=err_cr;
    fprintf(1,'\n epoch %d valid misclassification err %d (out of %d),  valid crerr %f \n',epoch,valid_err(epoch),size(validbatchdata,1)*size(validbatchdata,3),valid_crerr(epoch));
    
  end
  
  %%%% TEST STATS 
  %%%% Error rates 
  [testnumcases testnumdims testnumbatches]=size(testbatchdata);
  N=testnumcases;
  bias_hid= repmat(h1_biases,N,1);
  bias_pen = repmat(h2_biases,N,1);
  bias_top = repmat(topbiases,N,1);

  err=0;
  err_cr=0;
  counter=0;  
  for batch = 1:testnumbatches
    data = [testbatchdata(:,:,batch)];
    temp_h2 = temp_h2_test(:,:,batch); 
    target = [testbatchtargets(:,:,batch)]; 

    w1probs = 1./(1 + exp(-data*w1_vishid -temp_h2*w1_penhid - bias_hid  )); 
    w2probs = 1./(1 + exp(-w1probs*w2 - bias_pen)); 
    targetout = exp(w2probs*w_class + bias_top );
    targetout = targetout./repmat(sum(targetout,2),1,numlab);
    [I J]=max(targetout,[],2); 
    [I1 J1]=max(target,[],2); 
    counter=counter+length(find(J~=J1));  

    err_cr = err_cr- sum(sum( target(:,1:end).*log(targetout))) ;

  end
  test_err(epoch)=counter;
  test_crerr(epoch)=err_cr;
  fprintf(1,'\n epoch %d test misclassification err %d (out of %d),  test crerr %f \n',epoch,test_err(epoch),size(testbatchdata,1)*size(testbatchdata,3),test_crerr(epoch));

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  %%%% TRAINING STATS
  %%%% Error rates
  [numcases numdims numbatches]=size(batchdata);
  N=numcases;
  bias_hid= repmat(h1_biases,N,1);
  bias_pen = repmat(h2_biases,N,1);
  bias_top = repmat(topbiases,N,1);

  err=0;
  err_cr=0;
  counter=0;
  for batch = 1:numbatches
    data = [batchdata(:,:,batch)];
    temp_h2 = temp_h2_train(:,:,batch); 
    target = [batchtargets(:,:,batch)];

    w1probs = 1./(1 + exp(-data*w1_vishid -temp_h2*w1_penhid - bias_hid  ));
    w2probs = 1./(1 + exp(-w1probs*w2 - bias_pen));
    targetout = exp(w2probs*w_class + bias_top );
    targetout = targetout./repmat(sum(targetout,2),1,numlab);
    [I J]=max(targetout,[],2);
    [I1 J1]=max(target,[],2);
    counter=counter+length(find(J~=J1));

    err_cr = err_cr- sum(sum( target(:,1:end).*log(targetout))) ;

  end
  train_err(epoch)=counter;
  train_crerr(epoch)=err_cr;
  fprintf(1,'epoch %d test misclassification err %d train (out of %d), crerr %f \n',epoch, train_err(epoch),size(batchdata,1)*size(batchdata,3),train_crerr(epoch));

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  if exist('validbatchdata','var')
    save backprop_weights w1_vishid w1_penhid w2 w_class h1_biases ...
	h2_biases topbiases valid_err valid_crerr test_err test_crerr train_err train_crerr
  else
    save backprop_weights w1_vishid w1_penhid w2 w_class h1_biases h2_biases topbiases test_err test_crerr train_err train_crerr  
  end
  errsum=0;
  tt=0;
  [numcases numdims numbatches]=size(batchdata);
  rr = randperm(numbatches); 
  for batch = 1:ceil(numbatches/100)
    fprintf(1,'epoch %d batch %d\r',epoch,batch);
    
    data = zeros(100*numcases,numdims); 
    temp_h2 = zeros(100*numcases,numpens); 
    targets = zeros(100*numcases,size(batchtargets,2)); 
    tt1=(batch-1)*100+1:batch*100; 
    for tt=1:100
      minibatch_id = rr(mod(tt1(tt)-1,numbatches)+1);
      data( (tt-1)*numcases+1:tt*numcases,:) = batchdata(:,:,minibatch_id); 
      temp_h2( (tt-1)*numcases+1:tt*numcases,:) = temp_h2_train(:,:,minibatch_id); 
      targets( (tt-1)*numcases+1:tt*numcases,:) = batchtargets(:,:,minibatch_id); 
    end  
    %%% DO CG for 3 linesearches 

    VV = [w1_vishid(:)' w1_penhid(:)' w2(:)' w_class(:)' h1_biases(:)' h2_biases(:)' topbiases(:)']';
    Dim = [numdims; numhids; numpens; lambda];

    max_iter=3; 
    if epoch<6
      [X, fX, num_iter] = minimize(VV,'ECG0',max_iter,Dim,data,targets,temp_h2);
    else
      [X, fX, num_iter] = minimize(VV,'ECG',max_iter,Dim,data,targets,temp_h2);
    end 
    w1_vishid = reshape(X(1:numdims*numhids),numdims,numhids);
    xxx = numdims*numhids;
    w1_penhid = reshape(X(xxx+1:xxx+numpens*numhids),numpens,numhids);
    xxx = xxx+numpens*numhids;
    w2 = reshape(X(xxx+1:xxx+numhids*numpens),numhids,numpens);
    xxx = xxx+numhids*numpens;
    w_class = reshape(X(xxx+1:xxx+numpens*numlab),numpens,numlab);
    xxx = xxx+numpens*numlab;
    h1_biases = reshape(X(xxx+1:xxx+numhids),1,numhids);
    xxx = xxx+numhids;
    h2_biases = reshape(X(xxx+1:xxx+numpens),1,numpens);
    xxx = xxx+numpens;
    topbiases = reshape(X(xxx+1:xxx+numlab),1,numlab);
    xxx = xxx+numlab;

  end

end



