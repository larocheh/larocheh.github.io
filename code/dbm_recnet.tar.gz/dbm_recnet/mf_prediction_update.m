% Version 1.000
%
% Code provided by Hugo Larochelle and Ruslan Salakhutdinov
%
% Permission is granted for anyone to copy, use, modify, or distribute this
% program and accompanying programs and documents for any purpose, provided
% this copyright notice is retained and prominently displayed, along with
% a note saying that the original programs are available from our
% web page.
% The programs and documents are distributed without any warranty, express or
% implied.  As the programs were written for research purposes only, they have
% not been tested to the degree that would be advisable in any important
% application.  All use of these programs is entirely at the user's own risk.

max_iter=3;

if rand() < use_cg
  VV = [mfvishid(:)' mfhidpen(:)' mfhidbiases(:)' mfpenbiases(:)' ]'; 
  Dim = [numdims; numhid; numpen];
  
  [X, fX, num_iter] = minimize(VV,'ECG_ffdbm',max_iter,Dim,data,poshidprobs,pospenprobs);
  
  mfvishid = reshape(X(1:numdims*numhid),numdims,numhid);
  xxx = numdims*numhid;
  mfhidpen = reshape(X(xxx+1:xxx+numhid*numpen),numhid,numpen);
  xxx = xxx+numhid*numpen;
  mfhidbiases = reshape(X(xxx+1:xxx+numhid),1,numhid);
  xxx = xxx+numhid;
  mfpenbiases = reshape(X(xxx+1:xxx+numpen),1,numpen);
  
else
  gradpen = init_h2-pospenprobs;
  d_mfpenbiases = sum(gradpen,1);
  d_mfhidpen = init_h1'*gradpen;
  
  gradhid = (init_h1-poshidprobs) + (gradpen*mfhidpen').*(init_h1.*(1-init_h1));
  d_mfhidbiases = sum(gradhid,1);
  d_mfvishid = 2*data'*gradhid;
  
  mfvishidinc = momentum*mfvishidinc - epsilonw/numcases*d_mfvishid;
  mfhidpeninc = momentum*mfhidpeninc - epsilonw/numcases*d_mfhidpen;
  mfhidbiasesinc = momentum*mfhidbiasesinc - epsilonhb/numcases*d_mfhidbiases;
  mfpenbiasesinc = momentum*mfpenbiasesinc - epsilonhb/numcases*d_mfpenbiases;
  
  mfvishid = mfvishid + mfvishidinc;
  mfhidpen = mfhidpen + mfhidpeninc;
  mfhidbiases = mfhidbiases + mfhidbiasesinc;
  mfpenbiases = mfpenbiases + mfpenbiasesinc;
end