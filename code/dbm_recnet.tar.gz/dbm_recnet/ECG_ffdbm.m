% Version 1.000
%
% Code provided by Hugo Larochelle and Ruslan Salakhutdinov
%
% Permission is granted for anyone to copy, use, modify, or distribute this
% program and accompanying programs and documents for any purpose, provided
% this copyright notice is retained and prominently displayed, along with
% a note saying that the original programs are available from our
% web page.
% The programs and documents are distributed without any warranty, express or
% implied.  As the programs were written for research purposes only, they have
% not been tested to the degree that would be advisable in any important
% application.  All use of these programs is entirely at the user's own risk.

function [f, df] = ECG_ffdbm(VV,Dim,data,poshidprobs,pospenprobs);

numdims = Dim(1); 
numhid = Dim(2);
numpen = Dim(3); 
[numcases, dummy] = size(data);
N = size(data,1);

mfvishid = reshape(VV(1:numdims*numhid),numdims,numhid);
xxx = numdims*numhid;
mfhidpen = reshape(VV(xxx+1:xxx+numhid*numpen),numhid,numpen);
xxx = xxx+numhid*numpen;
mfhidbiases = reshape(VV(xxx+1:xxx+numhid),1,numhid);
xxx = xxx+numhid;
mfpenbiases = reshape(VV(xxx+1:xxx+numpen),1,numpen);
xxx = xxx+numpen;

init_h1 = 1./(1 + exp(-data*(2*mfvishid) - repmat(mfhidbiases,numcases,1)));
init_h2 = 1./(1 + exp(-init_h1*mfhidpen - repmat(mfpenbiases,numcases,1)));

ff = find(init_h1==1); 
init_h1(ff) = 1-eps; 
ff = find(init_h1==0); 
init_h1(ff) = eps; 
ff = find(init_h2==1); 
init_h2(ff) = 1-eps; 
ff = find(init_h2==0); 
init_h2(ff) = eps; 

f = -sum(sum( pospenprobs.*log(init_h2))) - sum(sum( (1-pospenprobs).*log(1-init_h2)))  ...
    -sum(sum( poshidprobs.*log(init_h1))) - sum(sum( (1-poshidprobs).*log(1-init_h1)));

gradpen = init_h2-pospenprobs;
d_mfpenbiases = sum(gradpen,1);
d_mfhidpen = init_h1'*gradpen;
  
gradhid = (init_h1-poshidprobs) + (gradpen*mfhidpen').*(init_h1.*(1-init_h1));
d_mfhidbiases = sum(gradhid,1);
d_mfvishid = 2*data'*gradhid;

df = [d_mfvishid(:)' d_mfhidpen(:)' d_mfhidbiases(:)' d_mfpenbiases(:)' ]'; 
