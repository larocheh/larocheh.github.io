#! /usr/bin/python

import sys, random
from random import seed

f = open('letter.data','r')
lines = f.readlines()
line = ''

letters = 'abcdefghijklmnopqrstuvwxyz'

data_lines = [ ]

for line in lines:
    tokens = line.strip('\n').strip('\t').split('\t')
    s = ''
    
    for t in range(6,len(tokens)):
        s = s + tokens[t] + ' '
    target = letters.find(tokens[1])
    if target < 0:
        print 'Target ' + tokens[1] + ' not found!'
    s = s + str(target)
    data_lines += [ s ]

# Shuffle data
seed(12345)
perm = range(len(data_lines))
random.shuffle(perm)
for i in perm:
    print data_lines[i]
            
