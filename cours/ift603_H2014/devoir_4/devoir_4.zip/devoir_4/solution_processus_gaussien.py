# -*- coding: utf-8 -*-

#####
# VotreNom (VotreMatricule) .~= À MODIFIER =~.
###

import numpy as np
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint
from pylab import *

class ProcessusGaussien:
    def __init__(self,beta, sigma2):
        """
        Régression avec processus gaussien, basée sur un noyau gaussien.

        L'argument ``beta`` est la précision (l'inverse de la
        variance) du bruit sur la cible.
        
        L'argument ``sigma2`` est l'hyper-paramètre \sigma^2 du noyau
        gaussien.
        """

        self.beta = beta
        self.sigma2 = sigma2
        
        self.K = None       # Matrice de Gram
        self.X = None       # Entrées de l'ensemble d'entraînement à garder en mémoire
        self.t = None       # Cibles de l'ensemble d'entraînement à garder en mémoire

    def entrainement(self, X,t):
        """
        Entraîne le processus gaussien. 

        Cette méthode doit calculer la matrice de Gram et l'assigner
        au champ ``self.K``. Cette méthode devrait donc appeler la
        méthode ``noyau()``.

        Cette méthode doit égalemnet assigner à des champs de l'objet
        l'ensemble d'entraînement (``X`` et ``t``).
        """

        # Calcul de la matrice de Gram

        # À IMPLÉMENTER

        # Garder l'ensemble d'entraînement en mémoire
        self.X = X
        self.t = t

    def prediction(self, x):
        """
        Retourne deux choses : la prédiction de la cible pour
        le tableau 1D Numpy ``x`` et la variance 
        de cette prédiction.

        Cette méthode devrait appeler la méthode ``noyau()``
        et utiliser la matrice de Gram ``self.K``.
        """

        # À IMPLÉMENTER

        return 0.,1.

    def noyau(self, X1, X2):
        """
        Retourne une matrice (tableau Numpy 2D) de taille ``len(X1)``
        par ``len(X2)``, dont l'élément à la position ``i,j`` est le
        noyau gaussien appliqué entre ``X1[i]`` et ``X2[j]``.
        """

        N1 = len(X1)
        N2 = len(X2)
        
        matrice_noyau = np.zeros((N1,N2))

        # À IMPLÉMENTER

        return matrice_noyau

    def erreur(self, t, prediction):
        """
        Retourne l'erreur de la différence au carré entre
        la cible ``t`` et la prédiction ``prediction``. 
        """
        
        # À IMPLÉMENTER

        return 10000.
