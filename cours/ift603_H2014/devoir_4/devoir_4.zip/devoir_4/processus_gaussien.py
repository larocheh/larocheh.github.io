# -*- coding: utf-8 -*-

from numpy import *
from pylab import *
import cPickle,sys

def save(p, filename):
    """
    Pickles object ``p`` and saves it to file ``filename``.
    """
    f=file(filename,'wb')
    cPickle.dump(p,f,cPickle.HIGHEST_PROTOCOL) 
    f.close()

def load(filename): 
    """
    Loads pickled object in file ``filename``.
    """
    f=file(filename,'rb')
    y=cPickle.load(f)
    f.close()
    return y


##############################
# Execution en tant que script
##############################

def main():
    usage = """Usage: python processus_gaussien.py"""
    if len(sys.argv) > 1:
        print usage
        return

    import solution_processus_gaussien as solution

    X,t = load('ensemble_entrainement.pkl')
    X_test, t_test = load('ensemble_test.pkl')

    solution_predictions_test = load('solution_predictions_test.pkl')
    solution_variances_test = load('solution_variances_test.pkl')
    solution_erreurs_test = load('solution_erreurs_test.pkl')

    beta = 100.
    sigma2 = 1000.
    gp = solution.ProcessusGaussien(beta,sigma2)

    # Entraînement du processus gaussien
    gp.entrainement(X,t)

    # Prédictions sur les ensembles d'entraînement et de test
    predictions_entrainement, variances_entrainement = zip(*[gp.prediction(x) for x in X])
    predictions_test, variances_test = zip(*[gp.prediction(x) for x in X_test])

    predictions_entrainement = np.array(predictions_entrainement).flatten()
    predictions_test = np.array(predictions_test).flatten()
    variances_entrainement = np.array(variances_entrainement).flatten()
    variances_test = np.array(variances_test).flatten()

    # Calcul des erreurs
    erreurs_entrainement = np.array( [gp.erreur(t_n,p_n)
                                      for t_n,p_n in zip(t,predictions_entrainement)])
    erreurs_test = np.array( [gp.erreur(t_n,p_n)
                              for t_n,p_n in zip(t_test,predictions_test)])

    print "Erreur d'entraînement :", "%.2f" % erreurs_entrainement.mean()
    print "Erreur de test :", "%.2f" % erreurs_test.mean()
    print ""

    if np.abs(predictions_test - solution_predictions_test).mean() < 1e-8:
        print 'Entraînement et prédiction (RÉUSSI)'
    else:
        print 'Entraînement et prédiction (ERREUR)'
            
    if np.abs(variances_test - solution_variances_test).mean() < 1e-8:
        print 'Variances des prédictions (RÉUSSI)'
    else:
        print 'Variances des prédictions (ERREUR)'
            
    if np.abs(erreurs_test - solution_erreurs_test).mean() < 1e-8:
        print 'Calcul des erreurs (RÉUSSI)'
    else:
        print 'Calcul des erreurs (ERREUR)'

if __name__ == "__main__":
    main()
