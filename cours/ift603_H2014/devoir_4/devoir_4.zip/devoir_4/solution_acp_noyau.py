# -*- coding: utf-8 -*-

#####
# VotreNom (VotreMatricule) .~= À MODIFIER =~.
###

import numpy as np
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint
from pylab import *

class ACPNoyau:
    def __init__(self,M,sigma2):
        """
        ACP à noyau, basée sur un noyau gaussien.

        L'argument ``M`` est le nombre de dimensions de l'espace vers lequel projeter les données.

        L'argument ``sigma2`` est l'hyper-paramètre \sigma^2 du noyau gaussien.
        """

        self.M = M
        self.sigma2 = sigma2

        self.A = None       # Paramètres de projection de l'ACP à noyau
        self.X = None       # Ensemble d'entraînement à garder en mémoire

    def entrainement(self, X):
        """
        Entraîne l'ACP à noyau.

        L'ensemble d'entraînement formé des entrées ``X`` (un tableau
        2D Numpy, où la n-ième rangée correspond à l'entrée x_n).

        Cette méthode doit correctement assigner la matrice (tableau 2D Numpy)
        ``self.A``, avec les vecteur propres (normalisés par la racine carrée
        de leur valeur propre) de la matrice de Gram centrée.

        Cette méthode doit également assigner à un champ de l'objet
        l'ensemble d'entraînement ``X``.
        """

        N,D = X.shape

        # Calcul de la matrice de Gram
        K = self.noyau(X,X)

        # Centrage du noyau
        K = self.centrage_noyau(K)

        # Calcul de la matrice ``self.A``

        # À IMPLÉMENTER

        # Garder l'ensemble d'entraînement en mémoire
        self.X = X

    def prediction(self, x):
        """
        Retourne la projection d'une entrée, representée par un
        tableau 1D Numpy ``x``.

        Cette méthode devrait appeler la méthode ``noyau()`` Elle
        suppose aussi que la méthode ``entrainement()`` a
        préalablement été appelée et doit utiliser la matrice
        ``self.A``.

        """

        # À IMPLÉMENTER                                                                                                                       

        # ATTENTION : ASSUREZ VOUS DE RETOURNER UN TABLEAU QUI EST BEL ET BIEN
        #             UN TABLEAU 1D, ET NON 2D!

        return np.zeros((self.M,))

    def noyau(self, X1, X2):
        """
        Retourne une matrice (tableau Numpy 2D) de taille ``len(X1)``
        par ``len(X2)``, dont l'élément à la position ``i,j`` est le
        noyau gaussien appliqué entre ``X1[i]`` et ``X2[j]``.
        """

        N1 = len(X1)
        N2 = len(X2)
        
        matrice_noyau = np.zeros((N1,N2))

        # À IMPLÉMENTER

        return matrice_noyau

    def centrage_noyau(self, K):
        """
        Retourne une version centrée de la matrice de Gram ``K``.
        """

        # À IMPLÉMENTER

        return K 
