# -*- coding: utf-8 -*-

from numpy import *
from pylab import *
import cPickle,sys
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint

def save(p, filename):
    """
    Pickles object ``p`` and saves it to file ``filename``.
    """
    f=file(filename,'wb')
    cPickle.dump(p,f,cPickle.HIGHEST_PROTOCOL) 
    f.close()

def load(filename): 
    """
    Loads pickled object in file ``filename``.
    """
    f=file(filename,'rb')
    y=cPickle.load(f)
    f.close()
    return y


##############################
# Execution en tant que script
##############################

def main():
    usage = """Usage: python acp_noyau"""
    if len(sys.argv) > 1:
        print usage
        return

    import solution_acp_noyau as solution


    X = load('ensemble_entrainement_acp.pkl')
    X_test = load('ensemble_test_acp.pkl')

    acp_noyau = solution.ACPNoyau(M=2,sigma2=100.)

    # Entraînement de l'ACP à noyau
    acp_noyau.entrainement(X)

    # Prédictions sur l'ensemble de test
    predictions_entrainement = np.array( [acp_noyau.prediction(x) for x in X])
    predictions_test = np.array( [acp_noyau.prediction(x) for x in X_test])

    solution_predictions_test = load('solution_predictions_test_acp.pkl')
    if np.abs(predictions_test - solution_predictions_test).sum() < 1e-8:
        print 'Entraînement et prédiction (RÉUSSI)'
    else:
        print 'Entraînement et prédiction (ERREUR)'
        
    # Visualisation de la réduction de dimensionalité
    fig, ax = plt.subplots()
    ax.scatter(predictions_entrainement[:,0],predictions_entrainement[:,1])

    # Ajouter l'image de chaque caractère
    from matplotlib.offsetbox import OffsetImage, AnnotationBbox
    for t in range(len(X)):
        xy = predictions_entrainement[t]
        imagebox = OffsetImage(X[t].reshape((28,28))[5:-5,5:-5], zoom=0.75,cmap=cm.Greys)
        ab = AnnotationBbox(imagebox,xy,frameon=True,pad=0.1)
        ax.add_artist(ab)

    draw()
    show()

if __name__ == "__main__":
    main()
