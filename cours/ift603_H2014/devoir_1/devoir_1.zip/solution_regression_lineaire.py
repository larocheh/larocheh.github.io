# -*- coding: utf-8 -*-

#####
# VotreNom (VotreMatricule) .~= À MODIFIER =~.
###

import numpy as np
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint

class RegressionLineaire:
    def __init__(self, lamb):
        self.lamb = lamb
        self.w = None

    def entrainement(self, X, t):
        """
        Entraîne la régression linéaire sur l'ensemble d'entraînement formé des 
        entrées ``X`` (un tableau 2D Numpy, où la n-ième rangée correspond à l'entrée
        x_n) et des cibles ``t`` (un tableau 1D Numpy où le
        n-ième élément correspond à la cible t_n). L'entraînement doit
        utiliser le poids de régularisation spécifié par ``self.lamb``.

        Cette méthode doit assigner le champs ``self.w`` au vecteur
        (tableau Numpy 1D) de taille D+1, tel que spécifié à l'équation
        3.28 du livre de Bishop.

        Il est également attendu que le calcul de ``self.w`` n'utilise
        pas d'inversion de matrice, mais utilise plutôt une procédure
        de résolution de système d'équations linéaires.
        """
        
        self.w = 0 # À IMPLÉMENTER

    def prediction(self, x):
        """
        Retourne la prédiction de la régression linéaire
        pour une entrée, representée par un tableau 1D Numpy ``x``.

        Cette méthode suppose que la méthode ``entrainement()``
        a préalablement été appelée. Elle doit utiliser le champs ``self.w``
        afin de calculer la prédiction y(x,w) (équation 3.1 et 3.3).
        """
        
        return 0 # À IMPLÉMENTER

    def erreur(self, t, prediction):
        """
        Retourne l'erreur de la différence au carré entre
        la cible ``t`` et la prédiction ``prediction``. 
        """
        
        return 0 # À IMPLÉMENTER
