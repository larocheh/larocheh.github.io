# -*- coding: utf-8 -*-

from numpy import *
from pylab import *
import cPickle,sys

def save(p, filename):
    """
    Pickles object ``p`` and saves it to file ``filename``.
    """
    f=file(filename,'wb')
    cPickle.dump(p,f,cPickle.HIGHEST_PROTOCOL) 
    f.close()

def load(filename): 
    """
    Loads pickled object in file ``filename``.
    """
    f=file(filename,'rb')
    y=cPickle.load(f)
    f.close()
    return y


##############################
# Execution en tant que script
##############################

def main():
    usage = """Usage: python regression_lineaire.py"""
    if len(sys.argv) > 1:
        print usage
        return

    import solution_regression_lineaire as solution

    X,t = load('ensemble_entrainement.pkl')
    X_test, t_test = load('ensemble_test.pkl')

    solution_predictions_entrainement = load('solution_predictions_entrainement.pkl')
    solution_predictions_test = load('solution_predictions_test.pkl')
    solution_erreurs_entrainement = load('solution_erreurs_entrainement.pkl')
    solution_erreurs_test = load('solution_erreurs_test.pkl')
    
    lamb = 0.1

    regression_lineaire = solution.RegressionLineaire(lamb)

    # Entraînement de la régression linéaire
    regression_lineaire.entrainement(X,t)

    # Prédictions sur les ensembles d'entraînement et de test
    predictions_entrainement = np.array( [regression_lineaire.prediction(x) for x in X])
    predictions_test = np.array( [regression_lineaire.prediction(x) for x in X_test])

    # Calcul des erreurs
    erreurs_entrainement = np.array( [regression_lineaire.erreur(t_n,p_n) 
                                      for t_n,p_n in zip(t,predictions_entrainement)])
    erreurs_test = np.array( [regression_lineaire.erreur(t_n,p_n)
                              for t_n,p_n in zip(t_test,predictions_test)])

    print "Erreur d'entraînement :", "%.2f" % erreurs_entrainement.mean()
    print "Erreur de test :", "%.2f" % erreurs_test.mean()
    print ""

    if np.abs(predictions_entrainement - solution_predictions_entrainement).mean() < 1e-8\
            and np.abs(predictions_test - solution_predictions_test).mean() < 1e-8:
        print 'Entraînement et prédiction (RÉUSSI)'
    else:
        print 'Entraînement et prédiction (ERREUR)'
            
    if np.abs(erreurs_entrainement - solution_erreurs_entrainement).mean() < 1e-8\
            and np.abs(erreurs_test - solution_erreurs_test).mean() < 1e-8:
        print 'Calcul des erreurs (RÉUSSI)'
    else:
        print 'Calcul des erreurs (ERREUR)'

if __name__ == "__main__":
    main()
