# -*- coding: utf-8 -*-

#####
# VotreNom (VotreMatricule) .~= À MODIFIER =~.
###

import numpy as np
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint
from pylab import *

class MelangeGaussiennes:
    def __init__(self,K,nb_iter,lamb):
        """
        Mélange de gaussiennes entraîné par l'algorithme EM

        L'argument ``K`` est le nombre de gaussiennes à utiliser dans le mélange.

        L'argument ``nb_iter`` est le nombre d'itérations de l'algorithme EM.

        L'argument ``lamb`` est une constante à ajouter à la diagonale
        des matrices covariance de chaque gaussienne (Sigma_k), afin de la régulariser
        et éviter qu'elles ne soient pas inversibles.
        """

        self.K = K
        self.nb_iter = nb_iter
        self.lamb = lamb

        self.pi = None      # Les probabilités a priori de chaque gaussienne
        self.mu = None      # Les moyennes de chaque gaussienne
        self.Sigma = None   # Les matrices de covariance de chaque gaussienne

    def entrainement(self, X):
        """
        Entraîne le mélange de gaussienne à l'aide de l'algorithme EM.

        L'ensemble d'entraînement formé des entrées ``X`` (un tableau
        2D Numpy, où la n-ième rangée correspond à l'entrée x_n).

        Cette méthode doit correctement assigner les champs suivants :

        - ``self.pi`` à un vecteur (tableau Numpy 1D scalaire), contenant
        la valeur des probabilités a priori de chaque kième gaussienne (``pi[k]``).

        - ``self.mu`` à une matrice (tableau Numpy 2D), dont chaque rangée
        correspond à la moyenne de chaque kième gaussienne (``mu[k]``).

        - ``self.Sigma`` à un tableau Numpy 3D, contenant la matrice de covariance 
        de chaque kième gaussienne (``Sigma[k]``).
        """

        N,D = X.shape

        # Initialisation de self.pi, self.mu, self.Sigma
        
        rng = np.random.mtrand.RandomState(1234)         # générateur de nombres aléatoires
        self.pi = np.ones(self.K)/float(self.K)          # pi[k] = 1./K
        self.mu = X[:self.K,:] + 0.1*rng.randn(self.K,D) # mu[k] initialisé à un exemple + bruit
        self.Sigma = np.zeros((self.K,D,D))
        for k in range(self.K):
            self.Sigma[k] = np.cov(X.T)                  # Sigma[k] initialisée à la matrice de covariance globale

        self.show_melange_gaussiennes(X,1)
        for i in range(self.nb_iter):
            # Étape E
            gamma = np.zeros((N,self.K))
            for n in range(N):
                gamma[n] = self.p_appartenance(X[n])

            # Étape M
            self.pi, self.mu, self.Sigma = self.maximiser_borne_inferieur(X, gamma)

            self.show_melange_gaussiennes(X,i+2)

    def prediction(self, x):
        """
        Retourne la log-probabilité (ln p(x)) d'une entrée, 
        representée par un tableau 1D Numpy ``x``.

        Cette méthode suppose que la méthode ``entrainement()``
        a préalablement été appelée. Elle doit utiliser les champs ``self.pi``,
        ``self.mu`` et ``self.Sigma``.
        """

        return 0 # À IMPLÉMENTER

    def erreur(self, prediction):
        """
        Retourne une mesure d'erreur pour le mélange de gaussienne.
        Doit simplement retourner la log-probabilité négative (-ln p(x)).
        """

        return 0        

    def p_gaussienne_k(self, x, k):
        """
        Retourne la probabilité N(x,mu[k],Sigma[k]) de ``x`` étant
        donné que ``x`` appartient à la kième gaussienne.
        """

        return 0 # À IMPLÉMENTER

    def p_appartenance(self, x):
        """
        Retourne un tableau Numpy 1D de taille ``self.K``, contenant
        les probabilités d'appartenance p(z_k=1|x) (aussi notée
        \gamma(z_k) dans les diapositives) pour chacune des kième
        gaussiennes. L'élément à la position ``k`` de ce tableau doit donc
        correspondre à la probabilité d'appartenance à la kième gaussienne.
        
        Cette méthode devrait entre autre utiliser la méthode ``self.p_gaussienne_k``.
        """

        p = np.zeros(self.K)

        # À IMPLÉMNETER

        return p
        
    def maximiser_borne_inferieur(self, X, gamma):
        """
        Exécute l'étape M de l'algorithme EM, c'est-à-dire met à jour
        les paramètres pi, mu et Sigma à partir des probabilités
        d'appartenance ``gamma``.  Cette étape est équivalente à maximiser
        la borne inférieur L(q, theta) de la log-probabilité des
        données d'entraînement (voir diapositive 58 du cours).

        L'argument ``X`` est un tableau 2D Numpy, où la n-ième rangée
        correspond à l'entrée x_n.

        L'argument ``gamma`` est une tableau 2D Numpy de taille N par
        K, dont l'élément ``gamma[n,k]`` correspond à la probabilité
        d'appartenance de l'entrée xn (``X[n]``) à la kième
        gaussienne.

        Le calcul des nouvelles matrices de covariances ``Sigma[k]``
        doit tenir de la régularisation ``self.lamb``.

        Cette méthode doit retourner les nouvelles valeurs que
        doivent prendre ``self.pi``, ``self.mu`` et ``self.Sigma``
        (dans cet ordre).
        """

        N,D = X.shape

        pi, mu, Sigma = np.zeros(self.K), np.zeros((self.K,D)), np.zeros((self.K,D,D))

        # À IMPLÉMENTER

        return pi, mu, Sigma

    def show_melange_gaussiennes(self,X,it):
        """
        Visualisation de l'initialisation et des  
        11 premières itérations de l'algorithme EM.
        """

        if it > 12:
            return 
        subplot(3,4,it)
        if it == 1:
            title('Initialisation')
        else:
            title('Iteration ' + str(it-1))
        xticks([])
        yticks([])

        def gauss_ellipse_2d(centroid, ccov, sdwidth=1, points=100):
            """
            Returns x,y vectors corresponding to ellipsoid at standard deviation sdwidth.
            """
            # from: http://www.mathworks.com/matlabcentral/fileexchange/16543
            mean = np.c_[centroid]
            tt = np.c_[np.linspace(0, 2*np.pi, points)]
            x = np.cos(tt); y=np.sin(tt);
            ap = np.concatenate((x,y), axis=1).T
            d, v = np.linalg.eig(ccov);
            d = np.diag(d)
            d = sdwidth * np.sqrt(d); # convert variance to sdwidth*sd
            bp = np.dot(v, np.dot(d, ap)) + np.tile(mean, (1, ap.shape[1])) 
            return bp[0,:], bp[1,:]


        N,D = X.shape
        if D == 2:
            scatter(X[:,0],X[:,1],marker='+')
            
            for k in range(self.K):
                scatter(self.mu[k,0],self.mu[k,1])
                x1,x2 = gauss_ellipse_2d(self.mu[k],self.Sigma[k])
                plot(x1,x2,'k',linewidth=2)

