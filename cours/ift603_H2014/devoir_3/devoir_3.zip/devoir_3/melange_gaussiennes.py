# -*- coding: utf-8 -*-

from numpy import *
from pylab import *
import cPickle,sys
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint

def save(p, filename):
    """
    Pickles object ``p`` and saves it to file ``filename``.
    """
    f=file(filename,'wb')
    cPickle.dump(p,f,cPickle.HIGHEST_PROTOCOL) 
    f.close()

def load(filename): 
    """
    Loads pickled object in file ``filename``.
    """
    f=file(filename,'rb')
    y=cPickle.load(f)
    f.close()
    return y


##############################
# Execution en tant que script
##############################

def main():
    usage = """Usage: python melange_gaussienne.py [K [nb_iter]]"""
    if len(sys.argv) > 3:
        print usage
        return

    if len(sys.argv) >= 2:
        K = int(sys.argv[1])
    else:
        K = 4
    
    if len(sys.argv) >= 3:
        nb_iter = int(sys.argv[2])
    else:
        nb_iter = 11

    import solution_melange_gaussiennes as solution

    # Création des paramètres du mélange de gaussiennes
    pi = np.array([0.2,0.3,0.1,0.4])
    mu = np.array([[0.,0.75],[0.5,1.],[1.,0.75],[0.5,0.25]])
    Sigma = np.zeros((4,2,2))
    Sigma[0] = np.array([[0.5,0.2],[0.2,0.25]])/50
    Sigma[1] = np.array([[0.5,0.05],[0.05,0.1]])/50
    Sigma[2] = np.array([[0.25,0.2],[0.2,0.5]])/50
    Sigma[3] = np.array([[0.5,0.],[0.,0.5]])/25

    N=50
    X = np.zeros((N,2))
    rng = np.random.mtrand.RandomState(123)
    for n in range(N):
        z = rng.multinomial(1,pi,size=1).flatten()
        k = z.argmax()
        X[n] = rng.multivariate_normal(mu[k],Sigma[k])

    N_test = 50
    X_test = np.zeros((N_test,2))
    for n in range(N_test):
        z = rng.multinomial(1,pi,size=1).flatten()
        k = z.argmax()
        X_test[n] = rng.multivariate_normal(mu[k],Sigma[k])


    # Test de p_gaussienne_k
    melange_gaussiennes = solution.MelangeGaussiennes(K=4,nb_iter=0,lamb=0.00001)
    melange_gaussiennes.pi = pi
    melange_gaussiennes.mu = mu
    melange_gaussiennes.Sigma = Sigma*20

    p = np.array([ [ melange_gaussiennes.p_gaussienne_k(X[i,:],k) for k in range(4) ] for i in range(10)])
    
    if K == 4 and nb_iter == 11:
        solution_p = load('solution_p_gaussienne_k.pkl')
        if np.abs(p - solution_p).sum() < 1e-8:
            print 'Calcul probabilités p_gaussienne_k (RÉUSSI)'
        else:
            print 'Calcul probabilités p_gaussienne_k (ERREUR)'
            
    # Test de p_appartenance
    p = np.array([ melange_gaussiennes.p_appartenance(X[i,:]) for i in range(10)])
    
    if K == 4 and nb_iter == 11:
        solution_p = load('solution_p_appartenance.pkl')
        if np.abs(p - solution_p).sum() < 1e-8:
            print 'Calcul probabilités d\'appartenance (RÉUSSI)'
        else:
            print 'Calcul probabilités d\'appartenance (ERREUR)'

    melange_gaussiennes = solution.MelangeGaussiennes(K=K,nb_iter=nb_iter,lamb=0.00001)

    # Entraînement de la régression linéaire
    melange_gaussiennes.entrainement(X)

    # Prédictions sur les ensembles d'entraînement et de test
    predictions_entrainement = np.array( [melange_gaussiennes.prediction(x) for x in X])

    # Calcul des erreurs
    erreurs_entrainement = np.array( [melange_gaussiennes.erreur(p_n) 
                                      for p_n in predictions_entrainement])

    if K == 4 and nb_iter == 11:
        solution_predictions_entrainement = load('solution_predictions_entrainement.pkl')
        solution_erreurs_entrainement = load('solution_erreurs_entrainement.pkl')
        if np.abs(predictions_entrainement - solution_predictions_entrainement).sum() < 1e-8:
            print 'Entraînement et prédiction (RÉUSSI)'
        else:
            print 'Entraînement et prédiction (ERREUR)'
                
        if np.abs(erreurs_entrainement - solution_erreurs_entrainement).sum() < 1e-8:
            print 'Calcul des erreurs (RÉUSSI)'
        else:
            print 'Calcul des erreurs (ERREUR)'

                
    predictions_test = np.array( [melange_gaussiennes.prediction(x) for x in X_test])
    erreurs_test = np.array( [melange_gaussiennes.erreur(p_n) 
                                      for p_n in predictions_test])

    print "Erreur d'entraînement :", "%.4f" % erreurs_entrainement.mean()
    print "Erreur de test :", "%.4f" % erreurs_test.mean()
    print ""

    show()

if __name__ == "__main__":
    main()
