# -*- coding: utf-8 -*-

#####
# VotreNom (VotreMatricule) .~= À MODIFIER =~.
###

import numpy as np
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint

workclass = ['Private', 'Self-emp-not-inc', 'Self-emp-inc', 'Federal-gov', 'Local-gov', 'State-gov', 'Without-pay', 'Never-worked']
education = ['Bachelors', 'Some-college', '11th', 'HS-grad', 'Prof-school', 'Assoc-acdm', 'Assoc-voc', '9th', '7th-8th', '12th', 'Masters', '1st-4th', '10th', 'Doctorate', '5th-6th', 'Preschool']
marital_status = ['Married-civ-spouse', 'Divorced', 'Never-married', 'Separated', 'Widowed', 'Married-spouse-absent', 'Married-AF-spouse']
occupation = ['Tech-support', 'Craft-repair', 'Other-service', 'Sales', 'Exec-managerial', 'Prof-specialty', 'Handlers-cleaners', 'Machine-op-inspct', 'Adm-clerical', 'Farming-fishing', 'Transport-moving', 'Priv-house-serv', 'Protective-serv', 'Armed-Forces']
relationship = ['Wife', 'Own-child', 'Husband', 'Not-in-family', 'Other-relative', 'Unmarried']
race = ['White', 'Asian-Pac-Islander', 'Amer-Indian-Eskimo', 'Other', 'Black']
sex = ['Female', 'Male']
native_country = ['United-States', 'Cambodia', 'England', 'Puerto-Rico', 'Canada', 'Germany', 'Outlying-US(Guam-USVI-etc)', 'India', 'Japan', 'Greece', 'South', 'China', 'Cuba', 'Iran', 'Honduras', 'Philippines', 'Italy', 'Poland', 'Jamaica', 'Vietnam', 'Mexico', 'Portugal', 'Ireland', 'France', 'Dominican-Republic', 'Laos', 'Ecuador', 'Taiwan', 'Haiti', 'Columbia', 'Hungary', 'Guatemala', 'Nicaragua', 'Scotland', 'Thailand', 'Yugoslavia', 'El-Salvador', 'Trinadad&Tobago', 'Peru', 'Hong', 'Holand-Netherlands']


def pretraitement_donnees(fichier):
    """
    Charge les données à partir du fichier ``fichier``
    et retourne la matrice des entrées et le vecteur des cibles.
    
    Chaque ligne du fichier de données ``fichier`` correspond à un
    exemple, à convertir sous la forme d'un vecteur x_n et d'une cible
    t_n et à insérer dans une matrice d'entrées ``X`` (un tableau 2D
    Numpy, où la n-ième rangée correspond à l'entrée x_n) et un
    vecteur de classes cibles ``t`` (un tableau 1D Numpy où le n-ième
    élément correspond à la cible t_n).

    Dans une ligne extraite de ``fichier`` se trouve 15 éléments
    séparés par une virgule et un espace (``', '``). Les 14 premiers
    éléments servent à construire l'entrée et le dernier (la classe,
    ``'<=50k ou ``'>50k'``) à construire la cible

    Chaque entrée (rangée de la matrice ``X``) devra donc être un vecteur,
    dans lequel les éléments de type catégorique (e.g. ``'State-gov'``,
    ``'Bachelors'``, ``'Never-married'``, ``'Adm-clerical'``, etc.) doivent
    être convertis en vecteurs binaires "one-hot". L'ordre 
    des valeurs catégoriques est spécifé par les listes de chaînes de caractères
    (définies ci-haut) suivantes:

    - ``workclass``        (2e élément d'une ligne)
    - ``education``        (4e élément)
    - ``marital_status``   (6e élément)
    - ``occupation``       (7e élément)
    - ``relationship``     (8e élément)
    - ``race``             (9e élément)
    - ``sex``              (10e élément)
    - ``native_country``   (14e élément)

    Pour les autres éléments, ils devront être convertis en ``float``.
    Pour certaines entrées, certains de ces éléments ne sont pas connus. Ils
    ont alors comme valuer ``'?'``.

    Chaque cible doit être convertie à 1 (classe ``'<=50K'``) ou 0 (classe ``'>50K'``).
    """

    ## À IMPLÉMENTER    
    return np.zeros((1,1)),np.zeros((1,))

class ClassifieurGeneratif:
    def __init__(self,lamb):
        """
        Algorithme de classification probabiliste générative.

        L'argument ``lamb`` est une constante à ajouter à la diagonale
        de la matrice de covariance (Sigma), afin de la régulariser
        et éviter qu'elle ne soit pas inversible.
        """
        self.p = None
        self.mu_1 = None
        self.Sigma = None
        self.w = None
        self.w_0 = None
        self.lamb = lamb

    def entrainement(self, X, t):
        """
        Entraîne le classifieur génératif sur l'ensemble d'entraînement formé des 
        entrées ``X`` (un tableau 2D Numpy, où la n-ième rangée correspond à l'entrée
        x_n) et des classes cibles ``t`` (un tableau 1D Numpy où le
        n-ième élément correspond à la cible t_n).

        Cette méthode doit assigner les champs suivants

        - ``self.p`` à un scalaire, tel que spécifié à l'équation
        4.73 du livre de Bishop.

        - ``self.mu_1`` à un vecteur (tableau Numpy 1D) de taille D, 
        tel que spécifié à l'équation 4.75 du livre de Bishop.

        - ``self.mu_2`` à un vecteur (tableau Numpy 1D) de taille D, 
        tel que spécifié à l'équation 4.76 du livre de Bishop.

        - ``self.Sigma`` à une matrice (tableau Numpy 2D) de taille DxD, 
        telle que spécifiée à l'équation 4.78 du livre de Bishop, mais
        à laquelle ``self.lamb`` doit être ADDITIONNÉ À LA DIAGONALE.

        - ``self.w`` à un vecteur (tableau Numpy 1D) de taille D, 
        tel que spécifié à l'équation 4.66 du livre de Bishop.

        - ``self.w_0`` à un scalaire, tel que spécifié à l'équation 
        4.67 du livre de Bishop.
        """

        # À IMPLÉMENTER
        self.p = 0
        self.mu_1 = 0
        self.mu_2 = 0
        self.Sigma = 0
        self.w = 0
        self.w_0 = 0

    def prediction(self, x):
        """
        Retourne la prédiction du classifieur génératif
        de la classe d'une entrée, representée par un tableau 1D Numpy ``x``.
        Doit donc retourner 1 si la classe prédite est ``'<=50K'``
        ou 0 si la classe prédite est ``'>50K'``.

        Cette méthode suppose que la méthode ``entrainement()``
        a préalablement été appelée. Elle doit utiliser les champs ``self.w``
        et ``self.w_0`` afin de faire cette classification.
        """
        
        return 0 # À IMPLÉMENTER

    def erreur(self, t, prediction):
        """
        Retourne l'erreur de classification, i.e. 
        1. si la cible ``t`` et la prédiction ``prediction``
        sont différentes, 0. sinon.
        """
        
        return float(1) # À IMPLÉMENTER

    def parametres(self):
        """
        Retourne les paramètres du modèle
        """
        return self.p, self.mu_1, self.mu_2, self.Sigma
