# -*- coding: utf-8 -*-

import math # pour le log

####################
# Solution ngramme #
####################

def extraire_vocabulaire(corpus_phrases, seuil):
    """
    Retourne un vocabulaire extrait d'un corpus de phrase
    en gardant les mots de fréquence plus grande ou égale à ``seuil``.
    
    IMPORTANT : les mots spéciaux ``'<unk>'`` et ``'</s>'`` doivent
    être inclus dans le vocabulaire.
    
    Args:
      corpus_phrases (list):  corpus de phrases, où chaque phrase est une liste de mots (``str``)
      seuil (int):            seuil sur la fréquence des mots

    Returns:
      ensemble (str) des mots dans le vocabulaire extrait

    """

    voc = {'<unk>', '</s>'}
    
    # À implémenter

    return voc


def remplacement_unk(phrase, vocabulaire):
    """
    Remplace les mots d'une phrase n'appartenant pas
    au vocabulaire par le mot spécial ``'<unk>'``.

    Args:
      phrase (list):       phrase sous la forme d'une liste de ``str``
      vocabulaire (set):   ensemble des mots (``str``) du vocabulaire

    Returns:
      phrase (list) où les mots hors-vocabulaire ont été remplacés par ``'<unk>'``

    """

    # À implémenter

    return phrase

class Trigramme:
    """
    Interface poru un modèle de langue trigramme.
    """

    def entrainement(self, corpus_phrases):
        """
        Extrait de ``corpus_phrases`` l'information
        nécessaire pour le calcul des probabilités des mots.
        Cette information est affectée à des champs internes
        de l'objet.

        Args:
          corpus_phrases (list):  corpus de phrases, où chaque phrase est une liste de mots (``str``)
        
        """

        raise NotImplemented()

    def log_probabilite_mot(self,w_i,w_i1, w_i2):
        """
        Calcul la log-probabilité en base naturelle (e) du mot ``w_i`` à
        partir des deux mots précédents ``w_i1`` et ``w_i2``.

        Args:
          w_i  (str):  mot pour lequel on évalue la log-probabilité
          w_i1 (str):  mot précédant ``w_i``
          w_i2 (str):  mot précédant ``w_i1``

        Returns:
          log-probabilité (float) du mot ``w_i`` étant donnés ``w_i1`` et ``w_i2``
        
        """

        raise NotImplemented()

    def log_probabilite_phrase(self, phrase):
        """
        Calcul la log-probabilité en base naturelle (e)  d'une phrase.

        Args:
          phrase (list:  liste des mots (``str``) d'une phrase

        Returns:
          log-probabilité (float) de la phrase
        
        """

        # À implémenter

        return 0.

class TrigrammeAddDelta(Trigramme):
    """
    Modèle de langue trigramme avec lissage add-delta
    """

    def __init__(self, delta, vocabulaire):
        """
        Créé une instance du modèle de langue, avec 
        vocabulaire ``vocabulaire``.

        Args:
          delta (float) :      constante à ajouter aux fréquences
          vocabulaire (set):   ensemble des mots (``str``) du vocabulaire

        """

        self.delta = delta
        self.vocabulaire = vocabulaire

    def entrainement(self, corpus_phrases):

        # À implémenter
        pass

    def log_probabilite_mot(self,w_i,w_i1, w_i2):

        # À implémenter
        
        return 0.
            

class TrigrammeInterpolation(Trigramme):
    """
    Modèle de langue trigramme avec lissage par interpolation.
    """

    def __init__(self, lambda_1, lambda_2, lambda_3):
        """
        Créé une instance du modèle de langue, avec 
        poids d'interpolation ``lambda1``, ``lambda2``
        et ``lambda3``.

        Args:
          lambda_1 (float):  poids du modèle trigramme
          lambda_2 (float):  poids du modèle bigramme
          lambda_3 (float):  poids du modèle unigramme

        """

        self.lambda_1 = lambda_1
        self.lambda_2 = lambda_2
        self.lambda_3 = lambda_3


    def entrainement(self, corpus_phrases):
        
        # À implémenter
        pass

    def log_probabilite_mot(self,w_i,w_i1, w_i2):

        # IMPORTANT: utiliser la version à N=2 si w_i1 est égal à <s>

        # À implémenter

        return 0.
