# -*- coding: utf-8 -*-

import numpy as np
import sys

##############################
# Execution en tant que script
##############################
def main():
    usage = """
Usage: python distance.py [cible source]

Si aucun argument n'est donné, une comparaison
sera faite avec un cas pour lequel les résultats
attendus sont connus. 

Optionnellement, des chaînes "cible" et "source" peuvent
être fournies, afin d'exécuter le script sur ces chaînes,
plutôt que le cas par défaut.
"""

    if len(sys.argv) == 3:
        target = sys.argv[1]
        source = sys.argv[2]
        eval = False
    elif len(sys.argv) == 1:
        target = "EXECUTION"
        source = "INTENTION"
        eval = True
    else:
        print usage
        return None

    # Fonctions de coût
    def ins_cost(c):      return 1.
    def del_cost(c):      return 1.
    def sub_cost(c1,c2):  return 2.0 * (c1!=c2)

    import solution_distance
    d,A = solution_distance.min_edit_distance(target,source,ins_cost,del_cost,sub_cost)

    if eval:
        sol_d = 8.0
        if d == sol_d: 
            print "[RÉUSSI]","Distance d'édition :"
            print d
        else: 
            print "[ÉCHEC]","Distance d'édition :"
            print d
            print ""
            print "La solution attendue est :"
            print sol_d
    else:
        print "Distance d'édition :"
        print d
    print ""

    if eval:
        sol_A = np.array([[False,  True, False, False, False, False, False, False, False],
                          [False, False,  True, False, False, False, False, False, False],
                          [False, False, False,  True, False, False, False, False, False],
                          [False, False, False, False, False, False, False, False, False],
                          [False, False, False, False,  True, False, False, False, False],
                          [False, False, False, False, False,  True, False, False, False],
                          [False, False, False, False, False, False,  True, False, False],
                          [False, False, False, False, False, False, False,  True, False],
                          [False, False, False, False, False, False, False, False,  True]], dtype=bool)

        if (sol_A - A).sum() == 0: 
            print "[RÉUSSI]","Matrice alignement:"
            print A
        else :
            print "[ÉCHEC]","Matrice alignement:"
            print A
            print ""
            print "La solution attendue est :"
            print sol_A

    else:
        print "Matrice alignement:"
        print A
    print ""

    str_align = solution_distance.illustration_alignement(target,source,A)

    if eval:
        sol_str_align = \
"""INTE*NTION
||||||||||
*EXECUTION
dss is    """

        if cmp(sol_str_align,str_align) == 0: 
            print "[RÉUSSI]","Illustration de l'alignement:"
            print str_align
        else: 
            print "[ÉCHEC]","Illustration de l'alignement:"
            print str_align
            print ""
            print "La solution attendue est :"
            print sol_str_align
            
    else:
        print "Illustration de l'alignement:"
        print str_align
    print ""


if __name__ == "__main__":
    main()
