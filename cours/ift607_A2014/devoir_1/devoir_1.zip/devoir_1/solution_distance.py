# -*- coding: utf-8 -*-

import numpy as np

#####################
# Solution distance #
#####################

def illustration_alignement(target,source,alignment):
    """
    Retourne une illustration de l'alignemnet (``alignment``) entre ``target`` et ``source``
    
    Args:
      target (list):       premier mot de la comparaison
      source (list):       deuxième mot de la comparaison
      alignment (ndarray): tableau (binaire) d'alignement entre les deux mots

    Returns:
      chaîne de caractère (str) illustrant l'alignement

    """

    # À implémenter
    
    return "À\nIMPLÉMENTER"

def min_edit_distance(target, source, ins_cost, del_cost, sub_cost):
    """
    Retourne la distance d'édition minimale entre ``target`` et ``source``
    
    Args:
      target (list):       premier mot de la comparaison
      source (list):       deuxième mot de la comparaison
      ins_cost (function): fonction d'un argument, donnant le coût d'insérer un caractère
      del_cost (function): fonction d'un argument, donnant le coût de supprimer un caractère
      sub_cost (function): fonction de deux arguments, donnant le coût de substituer deux caractères

    Returns:
      la distance d'édition et l'alignement sous la forme d'un tableau ``len(target)`` par ``len(source)``

    """

    # À implémenter

    return 0.0,np.zeros((len(target),len(source)),dtype=bool)
