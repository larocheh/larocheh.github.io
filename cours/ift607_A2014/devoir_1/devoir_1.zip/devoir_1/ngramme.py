# -*- coding: utf-8 -*-

import numpy as np
import math
import sys
import cPickle

##############################
# Execution en tant que script
##############################
def main():
    usage = """
Usage: python ngramme.py [mot1 mot2 ...]

Si aucun argument n'est donné, une comparaison
sera faite avec un cas pour lequel les résultats
attendus sont connus. 

Optionnellement, une phrase, spécifiée mot à mot,
peut être fournie. Le programme retournera alors
la log-probabilité de cette phrase.
"""

    if len(sys.argv) == 1:
        eval = True
    elif len(sys.argv) == 2 and sys.argv[1] == "-h":
        print usage
        return None
    else:
        phrase = sys.argv[1:]
        eval = False


    # Obtenir les données et divisier en entraînement, validation et test
    import nltk
    corpus_phrases = nltk.corpus.brown.sents()
    n_phrases = len(corpus_phrases)
    n_train = int(0.8 * n_phrases)
    n_valid = int(0.1 * n_phrases)
    
    corpus_phrases_entrainement = corpus_phrases[:n_train]
    corpus_phrases_validation   = corpus_phrases[n_train:n_train+n_valid]
    corpus_phrases_test         = corpus_phrases[n_train+n_valid:]
    
    import solution_ngramme

    # Obtention du vocabulaire
    vocabulaire = solution_ngramme.extraire_vocabulaire(corpus_phrases_entrainement, 3) 
    
    if eval:
        
        f = open('solution_vocabulaire.pkl','r')
        sol_vocabulaire = cPickle.load(f)
        f.close()

        if sol_vocabulaire == vocabulaire:
            print "[RÉUSSI] ",
        else:
            print "[ÉCHEC] ",

        print "Extraction de vocabulaire"

        def preproc(corpus,f,vocabulaire):
            return [ f(phrase,vocabulaire) for phrase in corpus ]

        test_phrase = corpus_phrases_validation[0] + ["blu","bla","bli"] + corpus_phrases_validation[1]
        phrase_unk = solution_ngramme.remplacement_unk(test_phrase,sol_vocabulaire)

        corpus_phrases_entrainement = preproc(corpus_phrases_entrainement,solution_ngramme.remplacement_unk, sol_vocabulaire)
        corpus_phrases_validation   = preproc(corpus_phrases_validation  ,solution_ngramme.remplacement_unk, sol_vocabulaire)
        corpus_phrases_test         = preproc(corpus_phrases_test        ,solution_ngramme.remplacement_unk, sol_vocabulaire)

        f = open('solution_unk.pkl','r')
        sol_phrase_unk = cPickle.load(f)
        f.close()

        if sol_phrase_unk == phrase_unk:
            print "[RÉUSSI] ",
        else:
            print "[ÉCHEC] ",

        print "Remplacement de mots hors-vocabulaire par <unk>"

        f = open('solution_unk_train.pkl','r')
        sol_corpus_phrases_entrainement = cPickle.load(f)
        f.close()

        f = open('solution_unk_valid.pkl','r')
        sol_corpus_phrases_validation = cPickle.load(f)
        f.close()

        f = open('solution_unk_test.pkl','r')
        sol_corpus_phrases_test = cPickle.load(f)
        f.close()

        # Construction des cas de test pour le calcul de probabilités
        test_phrase = sol_corpus_phrases_validation[0]
        test_mot_1 =   ['<s>','<s>',test_phrase[0]]
        test_mot_2 =   ['<s>',test_phrase[0],test_phrase[1]]
        test_mot_3 =   [test_phrase[0],test_phrase[1],test_phrase[2]]
        test_mot_fin = [test_phrase[-2],test_phrase[-1],'</s>']

        # Modèle avec lissage add-delta
        print ""
        print "Entraînement du modèle avec lissage add-delta"
        add_delta = solution_ngramme.TrigrammeAddDelta(0.001,sol_vocabulaire)
        add_delta.entrainement(sol_corpus_phrases_entrainement)
        
        lp_1 = add_delta.log_probabilite_mot(test_mot_1[2],test_mot_1[1], test_mot_1[0])
        lp_2 = add_delta.log_probabilite_mot(test_mot_2[2],test_mot_2[1], test_mot_2[0])
        lp_3 = add_delta.log_probabilite_mot(test_mot_3[2],test_mot_3[1], test_mot_3[0])
        lp_fin = add_delta.log_probabilite_mot(test_mot_fin[2],test_mot_fin[1], test_mot_fin[0])
        lp_phrase = add_delta.log_probabilite_phrase(test_phrase)
        
        probs = np.array([lp_1,lp_2,lp_3,lp_fin,lp_phrase])

        f = open('solution_probs_add_delta.pkl','r')
        sol_probs = cPickle.load(f)
        f.close()

        if np.sum((sol_probs - probs)**2) < 1e-8:
            print "[RÉUSSI] Calcul de probabilités"

        else:
            print "[ÉCHEC] Calcul de probabilités"
            print "n-gramme",test_mot_1,": log-prob attendue =",sol_probs[0],', log-prob obtenue =',probs[0]
            print "n-gramme",test_mot_2,": log-prob attendue =",sol_probs[1],', log-prob obtenue =',probs[1]
            print "n-gramme",test_mot_3,": log-prob attendue =",sol_probs[2],', log-prob obtenue =',probs[2]
            print "n-gramme",test_mot_fin,": log-prob attendue =",sol_probs[3],', log-prob obtenue =',probs[3]
            print "phrase",test_phrase,": log-prob attendue =",sol_probs[4],', log-prob obtenue =',probs[4]


        # Calcul des perplexités
        def perplexite(corpus_phrase, modele):
            N = 0.
            s = 0.
            for phrase in corpus_phrase:
                s += modele.log_probabilite_phrase(phrase)
                N += len(phrase)+1
            return math.exp(-s/N)
        
        print "Perplexité sur entraînement :",perplexite(sol_corpus_phrases_entrainement,add_delta)
        print "Perplexité sur validation :",perplexite(sol_corpus_phrases_validation,add_delta)
        print "Perplexité sur test :",perplexite(sol_corpus_phrases_test,add_delta)
        print ""

        # Modèle avec lissage par interpolation
        print "Entraînement du modèle avec lissage par interpolation"
        jelinek = solution_ngramme.TrigrammeInterpolation(0.5,0.4,0.1)
        jelinek.entrainement(sol_corpus_phrases_entrainement)

        lp_1 = jelinek.log_probabilite_mot(test_mot_1[2],test_mot_1[1], test_mot_1[0])
        lp_2 = jelinek.log_probabilite_mot(test_mot_2[2],test_mot_2[1], test_mot_2[0])
        lp_3 = jelinek.log_probabilite_mot(test_mot_3[2],test_mot_3[1], test_mot_3[0])
        lp_fin = jelinek.log_probabilite_mot(test_mot_fin[2],test_mot_fin[1], test_mot_fin[0])
        lp_phrase = jelinek.log_probabilite_phrase(test_phrase)
        
        probs = np.array([lp_1,lp_2,lp_3,lp_fin,lp_phrase])

        f = open('solution_probs_jelinek.pkl','r')
        sol_probs = cPickle.load(f)
        f.close()

        if np.sum((sol_probs - probs)**2) < 1e-8:
            print "[RÉUSSI] Calcul de probabilités"
        else:
            print "[ÉCHEC] Calcul de probabilités"
            print "n-gramme",test_mot_1,": log-prob attendue =",sol_probs[0],', log-prob obtenue =',probs[0]
            print "n-gramme",test_mot_2,": log-prob attendue =",sol_probs[1],', log-prob obtenue =',probs[1]
            print "n-gramme",test_mot_3,": log-prob attendue =",sol_probs[2],', log-prob obtenue =',probs[2]
            print "n-gramme",test_mot_fin,": log-prob attendue =",sol_probs[3],', log-prob obtenue =',probs[3]
            print "phrase",test_phrase,": log-prob attendue =",sol_probs[4],', log-prob obtenue =',probs[4]

        print "Perplexité sur entraînement :",perplexite(sol_corpus_phrases_entrainement,jelinek)
        print "Perplexité sur validation :",perplexite(sol_corpus_phrases_validation,jelinek)
        print "Perplexité sur test :",perplexite(sol_corpus_phrases_test,jelinek)
        print ""
        

    else:
        print "Phrase :", phrase
        phrase = solution_ngramme.remplacement_unk(phrase,vocabulaire)
        print "Phrase avec <unk> :", phrase

        def preproc(corpus,f,vocabulaire):
            return [ f(phrase,vocabulaire) for phrase in corpus ]

        corpus_phrases_entrainement = preproc(corpus_phrases_entrainement,solution_ngramme.remplacement_unk, vocabulaire)
        corpus_phrases_validation   = preproc(corpus_phrases_validation  ,solution_ngramme.remplacement_unk, vocabulaire)
        corpus_phrases_test         = preproc(corpus_phrases_test        ,solution_ngramme.remplacement_unk, vocabulaire)

        # Modèle avec lissage de add-delta
        add_delta = solution_ngramme.TrigrammeAddDelta(0.001,vocabulaire)
        add_delta.entrainement(corpus_phrases_entrainement)
        lp = add_delta.log_probabilite_phrase(phrase)
        print "Log-probabilité (add-delta) :",lp

        # Modèle avec lissage par interpolation
        jelinek = solution_ngramme.TrigrammeInterpolation(0.5,0.4,0.1)
        jelinek.entrainement(corpus_phrases_entrainement)
        lp = jelinek.log_probabilite_phrase(phrase)
        print "Log-probabilité (interpolation) :",lp

if __name__ == "__main__":
    main()
