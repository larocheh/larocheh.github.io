# -*- coding: utf-8 -*-

import numpy as np
import math
import sys
import cPickle

##############################
# Execution en tant que script
##############################
def main():
    usage = """
Usage: python ibm_1.py

Une comparaison sera faite avec un cas pour lequel 
les résultats attendus sont connus. 
"""

    if len(sys.argv) != 1:
        print usage
        return None

    fr = 'europarl-v7.smaller.tok.fr-en.fr'
    f = open(fr,'r')
    corpus_F = [ s.split() for s in f.readlines()]
    f.close()

    en = 'europarl-v7.smaller.tok.fr-en.en'
    f = open(en,'r')
    corpus_E = [ s.split() for s in f.readlines()]
    f.close()

    n_train =  int(0.95*len(corpus_E))
    corpus_E_tr = corpus_E[:n_train]
    corpus_E_vl = corpus_E[n_train:]
    
    corpus_F_tr = corpus_F[:n_train]
    corpus_F_vl = corpus_F[n_train:]

    import solution_ibm_1 as sol

    # Obtention du vocabulaire
    vocabulaire_F = sol.extraire_vocabulaire(corpus_F_tr, 3) 
    vocabulaire_E = sol.extraire_vocabulaire(corpus_E_tr, 3) 
    
    f = open('solution_vocabulaire_E.pkl','r')
    sol_vocabulaire_E = cPickle.load(f)
    f.close()

    f = open('solution_vocabulaire_F.pkl','r')
    sol_vocabulaire_F = cPickle.load(f)
    f.close()

    if vocabulaire_E == sol_vocabulaire_E and vocabulaire_F == sol_vocabulaire_F:
        print '[RÉUSSI] ',
    else:
        print '[ÉCHEC] ',

    vocabulaire_E = sol_vocabulaire_E
    vocabulaire_F = sol_vocabulaire_F

    print "Extraction de vocabulaire"


    corpus_F_tr = [ sol.remplacement_unk(s, vocabulaire_F) for s in corpus_F_tr ]
    corpus_F_vl = [ sol.remplacement_unk(s, vocabulaire_F) for s in corpus_F_vl ]

    corpus_E_tr = [ sol.remplacement_unk(s, vocabulaire_E) for s in corpus_E_tr ]
    corpus_E_vl = [ sol.remplacement_unk(s, vocabulaire_E) for s in corpus_E_vl ]

    f = open('solution_unk_train_F.pkl','r')
    sol_corpus_F_tr = cPickle.load(f)
    f.close()

    f = open('solution_unk_valid_F.pkl','r')
    sol_corpus_F_vl = cPickle.load(f)
    f.close()

    f = open('solution_unk_train_E.pkl','r')
    sol_corpus_E_tr = cPickle.load(f)
    f.close()

    f = open('solution_unk_valid_E.pkl','r')
    sol_corpus_E_vl = cPickle.load(f)
    f.close()

    if corpus_E_vl == sol_corpus_E_vl and corpus_F_vl == sol_corpus_F_vl:
        print '[RÉUSSI] ',
    else:
        print '[ÉCHEC] ',

    corpus_E_tr = sol_corpus_E_tr 
    corpus_E_vl = sol_corpus_E_vl 
    corpus_F_tr = sol_corpus_F_tr
    corpus_F_vl = sol_corpus_F_vl

    print "Remplacement de mots hors-vocabulaire par <unk>"

    ibm = sol.IBM1(vocabulaire_F, vocabulaire_E, 3)
    ibm.entrainement(corpus_F_tr,corpus_E_tr)

    f = open('solution_alignements_vl.pkl','r')
    sol_alignements_vl = cPickle.load(f)
    f.close()

    ok = True
    for i in range(len(corpus_E_vl)):
        phrase_F = corpus_F_vl[i]
        phrase_E = corpus_E_vl[i]
        algn = ibm.alignement(phrase_F,phrase_E)
        if np.sum(np.abs(algn-sol_alignements_vl[i])) != 0:
            ok = False
            print '[ÉCHEC] Alignement'
            print 'F =', ' '.join(phrase_F)
            print 'E =', ' '.join(phrase_E)
            print 'Prédit:'
            print np.array(algn,dtype=int)
            print 'Attendu:'
            print np.array(sol_alignements_vl[i],dtype=int)
            break
    if ok:
        print '[RÉUSSI] Alignement'

if __name__ == "__main__":
    main()
