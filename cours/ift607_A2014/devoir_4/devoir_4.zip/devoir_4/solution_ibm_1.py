# -*- coding: utf-8 -*-

import numpy as np

##################
# Solution ibm 1 #
##################

def extraire_vocabulaire(corpus_phrases, seuil):
    """
    Retourne un vocabulaire extrait d'un corpus de phrase
    en gardant les mots de fréquence plus grande ou égale à ``seuil``.
    
    IMPORTANT : les mots spéciaux ``'<unk>'`` et ``'</s>'`` doivent
    être inclus dans le vocabulaire.
    
    Args:
      corpus_phrases (list):  corpus de phrases, où chaque phrase est une liste de mots (``str``)
      seuil (int):            seuil sur la fréquence des mots

    Returns:
      ensemble (str) des mots dans le vocabulaire extrait

    """

    voc = {'<unk>'}
    
    # À implémenter

    return voc


def remplacement_unk(phrase, vocabulaire):
    """
    Remplace les mots d'une phrase n'appartenant pas
    au vocabulaire par le mot spécial ``'<unk>'``.

    Args:
      phrase (list):       phrase sous la forme d'une liste de ``str``
      vocabulaire (set):   ensemble des mots (``str``) du vocabulaire

    Returns:
      phrase (list) où les mots hors-vocabulaire ont été remplacés par ``'<unk>'``

    """

    # À implémenter

    return phrase


class IBM1:
    """
    Modèle d'alignement basé sur le modèle IBM 1.
    """

    def __init__(self, vocabulaire_F, vocabulaire_E, n_iterations):
        """
        Crée une instance du modèle de langue, avec 
        vocabulaire ``vocabulaire``.

        Args:
          vocabulaire_F (set):   ensemble des mots (``str``) du vocabulaire pour la langue F
          vocabulaire_E (set):   ensemble des mots (``str``) du vocabulaire pour la langue E
          n_iterations (int):    nombre d'itérations pour l'algorithme EM
        """

        self.vocabulaire_E = vocabulaire_E
        self.vocabulaire_F = vocabulaire_F
        self.n_iterations = n_iterations


    def entrainement(self, corpus_F, corpus_E):
        """
        Entraînement le modèle d'alignement avec l'algorithme EM, à partir
        du corpus parallèle formé des phrases dans ``corpus_F``
        et ``corpus_E``.

        IMPORTANT : ne pas oublier de traiter l'alignement avec le pseudo mot NULL

        Args:
          corpus_F (list):  corpus de phrases de la langue F
          corpus_E (list):  corpus de phrases de la langue E
        
        """

        # À implémenter

        pass

    def alignement(self,phrase_F, phrase_E):
        """
        Retourne une matrice de taille ``len(phrase_F)`` par ``len(phrase_E)``
        indiquant l'alignement entre une phrase de la langue F et une phrase
        de la langue E. L'entrée de la rangée i et colonne j doit être
        ``True`` si ``phrase_F[i]`` est aligné avec ``phrase_E[j]``, sinon ``False``.

        IMPORTANT : ne pas oublier de considérer l'alignement avec le pseudo mot NULL.
                    Si cet alignement est choisi, alors ne pas l'inclure dans la matrice
                    d'alignement.

        Args:
          phrase_F (list):  liste des mots de la phrase de la langue F
          phrase_E (list):  liste des mots de la phrase de la langue E

        Returns:
          alignement (numpy.ndarray) 
        
        """

        phrase_E = phrase_E + ['NULL']
        align = np.zeros((len(phrase_F),len(phrase_E)),dtype=bool)

        # À implémenter

        return align[:,:-1]


