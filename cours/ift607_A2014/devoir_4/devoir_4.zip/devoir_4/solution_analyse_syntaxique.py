# -*- coding: utf-8 -*-

import numpy as np
from nltk.tree import Tree

###############################
# Solution analyse_syntaxique #
###############################

def extraire_vocabulaire(corpus_treebank, seuil):
    """
    Retourne un vocabulaire extrait d'un corpus treebank
    en gardant les mots de fréquence plus grande ou égale à ``seuil``.

    IMPORTANT : le mot spécial ``'<unk>'`` doit être inclu dans le vocabulaire 
    
    Args:
      corpus_treebank (list):   corpus d'arbres, où chaque arbre est représenté par la classe ``Tree`` de NLTK
      seuil (int):              seuil sur la fréquence des mots

    Returns:
      ensemble (set) des mots dans le vocabulaire extrait

    """

    voc = {'<unk>'}
    
    # À implémenter

    return voc

def remplacement_unk(arbre, vocabulaire):
    """
    Remplace les mots d'un arbre n'appartenant pas
    au vocabulaire par le mot spécial ``'<unk>'``.

    Args:
      arbre (Tree):        arbre représenté par la classe ``Tree`` de NLTK
      vocabulaire (set):   vocabulaire

    Returns:
      arbre (Tree) où les mots hors-vocabulaire ont été remplacés par ``'<unk>'``

    """
    ret_arbre = arbre.copy(deep=True)

    # À implémenter

    return ret_arbre

class AnalyseurSyntaxique:
    """
    Analyseur syntaxique (parser) basé sur une PCFG, avec lissage add-delta
    """

    def __init__(self, vocabulaire, delta):
        """
        Crée une instance d'analyseur syntaxique

        Args:
          vocabulaire (set) :  ensemble des mots possibles
          delta (float) :      constante de lissage pour les tables de probabilités

        """

        self.vocabulaire = vocabulaire
        self.delta = delta

    def entrainement(self, corpus_treebank):
        """
        Extrait de ``corpus_treebank`` l'information
        nécessaire pour le calcul des probabilités de la PCFG.
        Cette information est affectée à des champs internes
        de l'objet.

        Les arbres sont représentés par la class ``Tree`` de NLTK
        (voir http://www.nltk.org/_modules/nltk/tree.html).
        Les arbres ont déjà été convertis en forme normale de Chomsky.

        Args:
          corpus_treebank (list):  corpus d'arbres, où chaque arbre est représenté par la classe ``Tree`` de NLTK
        
        """

        # À implémenter
        pass

    def prediction(self, phrase):
        """
        Retourne l'arbre syntaxique le plus vraisemblable, 
        représenté par la classe ``Tree`` de NLTK. Le symbole
        de départ à utiliser est ``'S'``.

        Args:
          phrase (list):  mots d'une phrase à analyser

        Returns:
          arbre syntaxique (``Tree``)

        """

        # À implmenter
        return Tree('S',[Tree(mot,[mot]) for mot in phrase])
