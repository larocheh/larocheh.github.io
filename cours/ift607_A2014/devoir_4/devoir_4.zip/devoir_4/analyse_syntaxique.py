# -*- coding: utf-8 -*-

import numpy as np
import sys
import cPickle
import nltk

# Fonctions pour normaliser les arbres syntaxiques
def remove_traces(t):
    children = [ c for c in t]
    for c in children:
        if type(c) == nltk.tree.Tree:
            # Remove traces
            if c.label().find('-NONE-') >= 0:
                t.remove(c)
            else:
                remove_traces(c)

def remove_subtrees_without_words(t):
    children = [ c for c in t]
    # If no children, then should be pruned
    if len(children) == 0:
        return True

    n_removed = 0
    for c in children:
        if type(c) == nltk.tree.Tree:
            flag = remove_subtrees_without_words(c)
            if flag:
                t.remove(c)
                n_removed += 1

    # If removed all children, then should be pruned
    if n_removed == len(children):
        return True

    return False

import re
def remove_pointers(t):
    children = [ c for c in t]
    for c in children:
        if type(c) == nltk.tree.Tree:
            # Remove pointers
            m = re.search('-[0-9]+',c.label())
            if m:
                c.set_label(c.label()[:m.start()])
            remove_pointers(c)

def remove_functional_tags(t):
    children = [ c for c in t]
    for c in children:
        if type(c) == nltk.tree.Tree:
            # Remove functional tags (i.e. '-BLA...')
            m = c.label().find('-')
            if m >=0:
                c.set_label(c.label()[:m])
            remove_functional_tags(c)

def normalize_tree(t):
    ret_t = t.copy(deep=True)
    remove_traces(ret_t)
    remove_subtrees_without_words(ret_t)
    remove_functional_tags(ret_t)
    return ret_t


# Script pour l'évaluation
def parseval(expected_trees, predicted_trees):
    correct = 0.
    expected = 0.
    predicted = 0.
    crossed = 0.
    # count numbers of correct, expected and predicted
    # constituents, as well as number of crossing brackets 
    tree_pairs = zip(expected_trees, predicted_trees)
    for expected_tree, predicted_tree in tree_pairs:
        # convert trees to spans
        expected_spans = get_spans(expected_tree)
        predicted_spans = get_spans(predicted_tree)
        expected += len(expected_spans)
        predicted += len(predicted_spans)
        # look for matching spans and crossing brackets
        for predicted_span in predicted_spans:
            had_match = had_crossing = False
            for expected_span in expected_spans:
                # look for matching spans
                if predicted_span == expected_span:
                   had_match = True
                # look for crossing brackets
                _, s1, e1 = predicted_span
                _, s2, e2 = expected_span
                if s1 < s2 < e1 < e2 or s2 < s1 < e2 < e1:
                   had_crossing = True
            # update correct and crossing bracket counts 
            correct += had_match
            crossed += had_crossing

    # calculate precision, recall, F-measure and crossing brackets 
    precision = correct / predicted
    recall = correct / expected
    f = 2 * precision * recall / (precision + recall) 
    crossing_brackets = crossed / predicted
    return precision, recall, f, crossing_brackets

def get_spans(tree, offset=0):
    start = offset

    if len(tree) == 1 and tree[0] != nltk.tree.Tree:
        return [] # parent of terminal does not contribute

    spans = []
    for child in tree:
        child_spans = get_spans(child, offset)
        if child_spans == []:
            offset += 1
        else:
            spans.extend(child_spans)
            offset = spans[-1][-1]

    # add the span for this subtree and return the span list 
    spans.append((tree.label(), start, offset))
    return spans


##############################
# Execution en tant que script
##############################
def main():
    usage = """
Usage: python analyse_syntaxique.py [mot1 mot2 ...]

Si aucun argument n'est donné, une comparaison
sera faite avec un cas pour lequel les résultats
attendus sont connus. 

Optionnellement, une phrase, spécifiée mot à mot,
peut être fournie. Le programme retournera alors
son arbre syntaxique. 
"""

    if len(sys.argv) == 1:
        eval = True
    elif len(sys.argv) == 2 and sys.argv[1] == "-h":
        print usage
        return None
    else:
        phrase = sys.argv[1:]
        eval = False

    from nltk.corpus import treebank
    all_treebank = treebank.parsed_sents()

    # Normalisation
    all_treebank = [normalize_tree(t) for t in all_treebank]

    # Mettre sous forme normale de Chomsky
    for t in all_treebank:
        t.chomsky_normal_form()
        t.collapse_unary(True,True)

    # Garde seulement les phrases d'au plus 10 mots
    # et les arbres avec 'S' comme racine
    new_treebank = []
    for t in all_treebank:
        if len(t.leaves()) <= 10 and t.label() == 'S':
            new_treebank += [t]
    all_treebank = new_treebank

    # Séparation en corpus d'entraînement, validation et test
    tot_trees = len(all_treebank)
    n_train = int(0.8*tot_trees)
    n_valid = int(0.1*tot_trees)

    train_treebank = all_treebank[:n_train]
    valid_treebank = all_treebank[n_train:(n_train+n_valid)]
    test_treebank =  all_treebank[(n_train+n_valid):]

    import solution_analyse_syntaxique as sol

    # Extraction du vocabulaire
    vocabulaire = sol.extraire_vocabulaire(train_treebank,2)

    if eval:
        f = open('solution_vocabulaire_analyse_syntaxique.pkl','r')
        sol_vocabulaire = cPickle.load(f)
        f.close()

        if sol_vocabulaire == vocabulaire:
            print "[RÉUSSI] ",
        else:
            print "[ÉCHEC] ",

        vocabulaire = sol_vocabulaire

    print "Extraction de vocabulaire"
    
    # Remplacement des mots par '<unk>'
    train_treebank = [sol.remplacement_unk(t, vocabulaire) for t in train_treebank]
    valid_treebank = [sol.remplacement_unk(t, vocabulaire) for t in valid_treebank]
    test_treebank  = [sol.remplacement_unk(t, vocabulaire) for t in  test_treebank]

    if eval:

        f = open('solution_unk_train_analyse_syntaxique.pkl','r')
        sol_train_treebank = cPickle.load(f)
        f.close()
    
        f = open('solution_unk_valid_analyse_syntaxique.pkl','r')
        sol_valid_treebank = cPickle.load(f)
        f.close()

        f = open('solution_unk_test_analyse_syntaxique.pkl','r')
        sol_test_treebank = cPickle.load(f)
        f.close()

        if sol_train_treebank == train_treebank and sol_valid_treebank == valid_treebank and sol_test_treebank == test_treebank:
            print "[RÉUSSI] ",
        else:
            print "[ÉCHEC] ",

        train_treebank = sol_train_treebank
        valid_treebank = sol_valid_treebank
        test_treebank  = sol_test_treebank

    print "Remplacement de mots hors-vocabulaire par <unk>"

    parser = sol.AnalyseurSyntaxique(vocabulaire, 1.)
    print "Entraînement de l'analyseur syntaxique...",
    parser.entrainement(train_treebank)
    print "terminé."

    #for t in train_treebank:
    #    pred = parser.prediction(t.leaves())
    #    pp = parser.prob(pred)
    #    tp = parser.prob(t)
    #    if pp +1e-6 < tp:
    #        raise Error('Analyser devrait retourner l'arbre de plus haute probabilité)

    if eval:
        train_prediction = [ parser.prediction(t.leaves()) for t in train_treebank]
        valid_prediction = [ parser.prediction(t.leaves()) for t in valid_treebank]
        test_prediction  = [ parser.prediction(t.leaves()) for t in  test_treebank]

        # Déconvertir la forme normale de Chomsky
        for t in train_treebank:
            t.un_chomsky_normal_form()
        for t in valid_treebank:
            t.un_chomsky_normal_form()
        for t in test_treebank:
            t.un_chomsky_normal_form()
        for t in train_prediction:
            t.un_chomsky_normal_form()
        for t in valid_prediction:
            t.un_chomsky_normal_form()
        for t in test_prediction:
            t.un_chomsky_normal_form()

        f = open('solution_valid_prediction_analyse_syntaxique.pkl','r')
        sol_valid_prediction = cPickle.load(f)
        f.close()

        if valid_prediction == sol_valid_prediction:
            print "[RÉUSSI] ",
        else:
            print "[ÉCHEC] ",

        print "Inférence des arbres syntaxiques"

        import itertools
        def print_eval(treebank,prediction):
            precision, recall, f, crossing_brackets = parseval(treebank,prediction)
            print "prec =", precision, "rappel =", recall, "F-mesure = ", f, "crossing = ", crossing_brackets

        print "Entraînement :",
        print_eval(train_treebank, train_prediction)
        print "Validation :",
        print_eval(valid_treebank, valid_prediction)
        print "Test :",
        print_eval(test_treebank, test_prediction)

    else:
        # Remplacement par <unk>
        phrase_unk = sol.remplacement_unk(nltk.tree.Tree('S',phrase),vocabulaire).leaves()
        t = parser.prediction(phrase_unk)
        t.un_chomsky_normal_form()

        # Remettre les mots remplacés par <unk>
        def revert_unk(tree, phrase, id=0):
            for i,c in enumerate(tree):
                if type(c) == nltk.tree.Tree:
                    id = revert_unk(c, phrase, id)
                else:
                    tree[i] = phrase[id]
                    id+=1
            return id
        revert_unk(t, phrase)
        print t

if __name__ == "__main__":
    main()
