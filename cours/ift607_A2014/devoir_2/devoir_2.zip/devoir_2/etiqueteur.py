# -*- coding: utf-8 -*-

import numpy as np
import math
import sys
import cPickle

##############################
# Execution en tant que script
##############################
def main():
    usage = """
Usage: python etiqueteur.py [mot1 mot2 ...]

Si aucun argument n'est donné, une comparaison
sera faite avec un cas pour lequel les résultats
attendus sont connus. 

Optionnellement, une phrase, spécifiée mot à mot,
peut être fournie. Le programme retournera l'étiquetage
morpho-syntaxique prédit par le modèle HMM.
"""

    if len(sys.argv) == 1:
        eval = True
    elif len(sys.argv) == 2 and sys.argv[1] == "-h":
        print usage
        return None
    else:
        phrase = sys.argv[1:]
        eval = False


    # Obtenir les données et divisier en entraînement, validation et test
    import nltk
    corpus_phrases = nltk.corpus.treebank.tagged_sents()
    n_phrases = len(corpus_phrases)
    n_train = int(0.8 * n_phrases)
    n_valid = int(0.1 * n_phrases)
    
    corpus_phrases_entrainement = corpus_phrases[:n_train]
    corpus_phrases_validation   = corpus_phrases[n_train:n_train+n_valid]
    corpus_phrases_test         = corpus_phrases[n_train+n_valid:]
    
    # Obtention du tagset
    tagset = set([ t for w,t in nltk.corpus.treebank.tagged_words()])
    tagset.remove('-NONE-')

    # Enlever les -None-
    def is_not_NONE(word_and_tag):
        return word_and_tag[1] != '-NONE-'
    corpus_phrases_entrainement = [ filter(is_not_NONE,wt) for wt in corpus_phrases_entrainement ]
    corpus_phrases_validation   = [ filter(is_not_NONE,wt) for wt in corpus_phrases_validation   ]
    corpus_phrases_test         = [ filter(is_not_NONE,wt) for wt in corpus_phrases_test         ]
    
    import solution_etiqueteur

    # Obtention du vocabulaire
    vocabulaire = solution_etiqueteur.extraire_vocabulaire(corpus_phrases_entrainement, 2) 
    
    if eval:
        
        f = open('solution_vocabulaire_etiqueteur.pkl','r')
        sol_vocabulaire = cPickle.load(f)
        f.close()

        if sol_vocabulaire == vocabulaire:
            print "[RÉUSSI] ",
        else:
            print "[ÉCHEC] ",

        print "Extraction de vocabulaire"

        def preproc(corpus,f,vocabulaire):
            return [ f(phrase,vocabulaire) for phrase in corpus ]

        test_phrase = corpus_phrases_validation[0] + [("blu",'NN'),("bla",'NN'),("bli",'NN')] + corpus_phrases_validation[1]
        phrase_unk = solution_etiqueteur.remplacement_unk(test_phrase,sol_vocabulaire)

        corpus_phrases_entrainement = preproc(corpus_phrases_entrainement,solution_etiqueteur.remplacement_unk, sol_vocabulaire)
        corpus_phrases_validation   = preproc(corpus_phrases_validation  ,solution_etiqueteur.remplacement_unk, sol_vocabulaire)
        corpus_phrases_test         = preproc(corpus_phrases_test        ,solution_etiqueteur.remplacement_unk, sol_vocabulaire)

        f = open('solution_unk_etiqueteur.pkl','r')
        sol_phrase_unk = cPickle.load(f)
        f.close()

        if sol_phrase_unk == phrase_unk:
            print "[RÉUSSI] ",
        else:
            print "[ÉCHEC] ",

        print "Remplacement de mots hors-vocabulaire par <unk>"

        f = open('solution_unk_train_etiqueteur.pkl','r')
        sol_corpus_phrases_entrainement = cPickle.load(f)
        f.close()

        f = open('solution_unk_valid_etiqueteur.pkl','r')
        sol_corpus_phrases_validation = cPickle.load(f)
        f.close()

        f = open('solution_unk_test_etiqueteur.pkl','r')
        sol_corpus_phrases_test = cPickle.load(f)
        f.close()

        # Modèle HMM pour l'étiquetage morpho-syntaxique
        print ""
        print "Entraînement de l'étiqueteur HMM"
        hmm = solution_etiqueteur.Etiqueteur(tagset,sol_vocabulaire,0.0001)
        hmm.entrainement(sol_corpus_phrases_entrainement)
        
        tags = hmm.etiqueter([w for w,t in sol_corpus_phrases_validation[1]])
        
        f = open('solution_tags_etiqueteur.pkl','r')
        sol_tags = cPickle.load(f)
        f.close()
        
        if cmp(tags,sol_tags) == 0:
            print "[RÉUSSI] Entrainement et etiqueter"
        
        else:
            print "[ÉCHEC] Entrainement et etiqueter"
            print "Obtenu :",tags
            print "Attendu :",sol_tags
        
        # Calcul de la précision
        def precision(corpus_phrase, modele):
            N = 0.
            s = 0.
            for phrase in corpus_phrase:
                mots = [w for w,t in phrase]
                pred_tags = modele.etiqueter(mots)
                tags = [t for w,t in phrase]
                s += np.array([ pt==t for pt,t in zip(pred_tags,tags)]).sum()
                N += len(mots)
            return s / N
        
        precision_entrainement = precision(sol_corpus_phrases_entrainement,hmm)
        precision_validation   = precision(sol_corpus_phrases_validation  ,hmm)
        precision_test         = precision(sol_corpus_phrases_test        ,hmm)

        precisions = [precision_entrainement, precision_validation, precision_test]
        
        f = open('solution_tags_precisions.pkl','r')
        sol_precision_entrainement, sol_precision_validation, sol_precision_test = cPickle.load(f)
        f.close()
        
        if np.abs(precision_entrainement - sol_precision_entrainement) < 1e-8:
            print "[RÉUSSI] Précision sur entraînement :",precision(sol_corpus_phrases_entrainement,hmm)
        else:
            print "[ÉCHEC] Précision sur entraînement :",precision(sol_corpus_phrases_entrainement,hmm)
            print "Précision attendue :",sol_precision_entrainement

        if np.abs(precision_validation - sol_precision_validation) < 1e-8:
            print "[RÉUSSI] Précision sur validation :",precision(sol_corpus_phrases_validation,hmm)
        else:
            print "[ÉCHEC] Précision sur validation :",precision(sol_corpus_phrases_validation,hmm)
            print "Précision attendue :",sol_precision_validation

        if np.abs(precision_test - sol_precision_test) < 1e-8:
            print "[RÉUSSI] Précision sur test :",precision(sol_corpus_phrases_test,hmm)
        else:
            print "[ÉCHEC] Précision sur test :",precision(sol_corpus_phrases_test,hmm)
            print "Précision attendue :",sol_precision_test

        print ""
        #print "Performance baseline"
        ## Calcul de la précision baseline
        #def precision_baseline(corpus_phrase, modele):
        #    N = 0.
        #    s = 0.
        #    for phrase in corpus_phrase:
        #        mots = [w for w,t in phrase]
        #        pred_tags = modele.etiqueter_baseline(mots)
        #        tags = [t for w,t in phrase]
        #        s += np.array([ pt==t for pt,t in zip(pred_tags,tags)]).sum()
        #        N += len(mots)
        #    return s / N
        #
        #print "Précision sur entraînement :",precision_baseline(sol_corpus_phrases_entrainement,hmm)
        #print "Précision sur validation :",precision_baseline(sol_corpus_phrases_validation,hmm)
        #print "Précision sur test :",precision_baseline(sol_corpus_phrases_test,hmm)
        #print ""

    else:
        print "Phrase :", phrase
        phrase_et_tag = [ (w,None) for w in phrase ]
        phrase_unk = [ w for w,t, in solution_etiqueteur.remplacement_unk(phrase_et_tag,vocabulaire) ]
        print "Phrase avec <unk> :", phrase_unk

        def preproc(corpus,f,vocabulaire):
            return [ f(phrase,vocabulaire) for phrase in corpus ]

        corpus_phrases_entrainement = preproc(corpus_phrases_entrainement,solution_etiqueteur.remplacement_unk, vocabulaire)
        corpus_phrases_validation   = preproc(corpus_phrases_validation  ,solution_etiqueteur.remplacement_unk, vocabulaire)
        corpus_phrases_test         = preproc(corpus_phrases_test        ,solution_etiqueteur.remplacement_unk, vocabulaire)

        # Modèle HMM pour l'étiquetage morpho-syntaxique
        print ""
        print "Entraînement de l'étiqueteur HMM"
        hmm = solution_etiqueteur.Etiqueteur(tagset,vocabulaire,0.0001)
        hmm.entrainement(corpus_phrases_entrainement)

        tags = hmm.etiqueter(phrase_unk)

        print "Étiquettes prédites :"
        for w,t in zip(phrase,tags):
            print w + "/" + t + ' ',
        print ""

if __name__ == "__main__":
    main()
