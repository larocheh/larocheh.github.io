# -*- coding: utf-8 -*-

import numpy as np
import sys

def extraire_vocabulaire(corpus_phrases, seuil):
    """
    Retourne un vocabulaire extrait d'un corpus de phrase
    en gardant les mots de fréquence plus grande ou égale à ``seuil``.

    IMPORTANT : le mot spécial ``'<unk>'`` doit être inclu dans le
    vocabulaire.
    
    Args:
      corpus_phrases (list):  corpus de phrases, où chaque phrase est une liste de paires de mots (``str``) et d'étiquettes (``str``)
      seuil (int):            seuil sur la fréquence des mots

    Returns:
      ensemble (str) des mots dans le vocabulaire extrait

    """

    voc = {'<unk>'}
    
    # À implémenter

    return voc


def remplacement_unk(phrase, vocabulaire):
    """
    Remplace les mots d'une phrase n'appartenant pas
    au vocabulaire par le mot spécial ``'<unk>'``.

    Args:
      phrase (list):       phrase sous la forme d'une liste de paires de ``str``
      vocabulaire (set):   ensemble des mots (``str``) du vocabulaire

    Returns:
      phrase (list) où les mots hors-vocabulaire ont été remplacés par ``'<unk>'``

    """

    # À implémenter

    return phrase

class Etiqueteur:
    """
    Étiqueteur morpho-syntaxique basé sur un HMM, avec lissage add-delta.
    """

    def __init__(self, tagset, vocabulaire, delta):
        """
        Crée une instance d'étiqueteur morpho-syntaxique.

        Args:
          tagset (set) :       ensemble des étiquettes grammaticales possibles
          vocabulaire (set) :  ensemble des mots possibles
          delta (float) :      constante de lissage pour les tables de probabilités

        """

        self.tagset = tagset
        self.vocabulaire = vocabulaire
        self.delta = delta

    def entrainement(self, corpus_phrases):
        """
        Extrait de ``corpus_phrases`` l'information
        nécessaire pour le calcul des probabilités du HMM.
        Cette information est affectée à des champs internes
        de l'objet.

        Args:
          corpus_phrases (list):  corpus de phrases, où chaque phrase est une liste de paires de mots (``str``) et étiquettes (``str``)
        
        """

        # À implémenter
        pass

    def etiqueter(self, phrase):
        """
        Retourne un étiquetage de la phrase ``phrase`` (liste de mots).

        Args:
          phrase (list): phrase sous la forme d'une liste de mots (``str``)

        Returns:
          liste (list) des étiquettes de chaque mot dans ``phrase``
        """

        return ['NN'] * len(phrase)
