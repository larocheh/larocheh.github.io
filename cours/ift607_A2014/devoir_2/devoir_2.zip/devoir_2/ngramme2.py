# -*- coding: utf-8 -*-

import numpy as np
import math
import sys
import cPickle

##############################
# Execution en tant que script
##############################
def main():
    usage = """
Usage: python ngramme2.py [mot1 mot2 ...]

Si aucun argument n'est donné, une comparaison
sera faite avec un cas pour lequel les résultats
attendus sont connus. 

Optionnellement, une phrase, spécifiée mot à mot,
peut être fournie. Le programme retournera alors
la log-probabilité de cette phrase.
"""

    if len(sys.argv) == 1:
        eval = True
    elif len(sys.argv) == 2 and sys.argv[1] == "-h":
        print usage
        return None
    else:
        phrase = sys.argv[1:]
        eval = False


    # Obtenir les données et divisier en entraînement, validation et test
    import nltk
    corpus_phrases = nltk.corpus.brown.sents()
    n_phrases = len(corpus_phrases)
    n_train = int(0.8 * n_phrases)
    n_valid = int(0.1 * n_phrases)
    
    corpus_phrases_entrainement = corpus_phrases[:n_train]
    corpus_phrases_validation   = corpus_phrases[n_train:n_train+n_valid]
    corpus_phrases_test         = corpus_phrases[n_train+n_valid:]
    
    import solution_ngramme2

    # Obtention du vocabulaire
    vocabulaire = solution_ngramme2.extraire_vocabulaire(corpus_phrases_entrainement, 3) 
    
    if eval:
        
        f = open('solution_vocabulaire.pkl','r')
        sol_vocabulaire = cPickle.load(f)
        f.close()

        f = open('solution_unk_train.pkl','r')
        sol_corpus_phrases_entrainement = cPickle.load(f)
        f.close()

        f = open('solution_unk_valid.pkl','r')
        sol_corpus_phrases_validation = cPickle.load(f)
        f.close()

        f = open('solution_unk_test.pkl','r')
        sol_corpus_phrases_test = cPickle.load(f)
        f.close()

        # Construction des cas de test pour le calcul de probabilités
        test_phrase = sol_corpus_phrases_validation[0]
        test_mot_1 =   ['<s>','<s>',test_phrase[0]]
        test_mot_2 =   ['<s>',test_phrase[0],test_phrase[1]]
        test_mot_3 =   [test_phrase[0],test_phrase[1],test_phrase[2]]
        test_mot_fin = [test_phrase[-2],test_phrase[-1],'</s>']

        # Calcul des perplexités
        def perplexite(corpus_phrase, modele):
            N = 0.
            s = 0.
            for phrase in corpus_phrase:
                s += modele.log_probabilite_phrase(phrase)
                N += len(phrase)+1
            return math.exp(-s/N)
        
        #save = True

        # Modèle avec lissage par repli de Katz
        print ""
        print "Entraînement du modèle avec lissage par repli de Katz"
        katz = solution_ngramme2.TrigrammeRepliKatz(0.001,sol_vocabulaire)
        katz.entrainement(sol_corpus_phrases_entrainement)
        
        lp_1 = katz.log_probabilite_mot(test_mot_1[2],test_mot_1[1], test_mot_1[0])
        lp_2 = katz.log_probabilite_mot(test_mot_2[2],test_mot_2[1], test_mot_2[0])
        lp_3 = katz.log_probabilite_mot(test_mot_3[2],test_mot_3[1], test_mot_3[0])
        lp_fin = katz.log_probabilite_mot(test_mot_fin[2],test_mot_fin[1], test_mot_fin[0])
        lp_phrase = katz.log_probabilite_phrase(test_phrase)
        
        probs = np.array([lp_1,lp_2,lp_3,lp_fin,lp_phrase])
        
        #if save:
        #    f = open('solution_probs_katz.pkl','w')
        #    cPickle.dump(probs,f)
        #    f.close()
        
        f = open('solution_probs_katz.pkl','r')
        sol_probs = cPickle.load(f)
        f.close()
        
        if np.sum((sol_probs - probs)**2) < 1e-8:
            print "[RÉUSSI] Calcul de probabilités"
        
        else:
            print "[ÉCHEC] Calcul de probabilités"
            print "n-gramme",test_mot_1,": log-prob attendue =",sol_probs[0],', log-prob obtenue =',probs[0]
            print "n-gramme",test_mot_2,": log-prob attendue =",sol_probs[1],', log-prob obtenue =',probs[1]
            print "n-gramme",test_mot_3,": log-prob attendue =",sol_probs[2],', log-prob obtenue =',probs[2]
            print "n-gramme",test_mot_fin,": log-prob attendue =",sol_probs[3],', log-prob obtenue =',probs[3]
            print "phrase",test_phrase,": log-prob attendue =",sol_probs[4],', log-prob obtenue =',probs[4]
        
        print "Perplexité sur entraînement :",perplexite(sol_corpus_phrases_entrainement,katz)
        print "Perplexité sur validation :",perplexite(sol_corpus_phrases_validation,katz)
        print "Perplexité sur test :",perplexite(sol_corpus_phrases_test,katz)
        print ""

        #test_somme_1(test_mot_1,  katz,sol_vocabulaire)
        #test_somme_1(test_mot_2,  katz,sol_vocabulaire)
        #test_somme_1(test_mot_3,  katz,sol_vocabulaire)
        #test_somme_1(test_mot_fin,katz,sol_vocabulaire)
        
        # Modèle avec lissage interpolé Kneser Ney
        print "Entraînement du modèle avec lissage interpolé Kneser Ney"
        kneser_ney= solution_ngramme2.TrigrammeKneserNey(0.9)
        kneser_ney.entrainement(sol_corpus_phrases_entrainement)

        lp_1 = kneser_ney.log_probabilite_mot(test_mot_1[2],test_mot_1[1], test_mot_1[0])
        lp_2 = kneser_ney.log_probabilite_mot(test_mot_2[2],test_mot_2[1], test_mot_2[0])
        lp_3 = kneser_ney.log_probabilite_mot(test_mot_3[2],test_mot_3[1], test_mot_3[0])
        lp_fin = kneser_ney.log_probabilite_mot(test_mot_fin[2],test_mot_fin[1], test_mot_fin[0])
        lp_phrase = kneser_ney.log_probabilite_phrase(test_phrase)
        
        probs = np.array([lp_1,lp_2,lp_3,lp_fin,lp_phrase])

        #if save:
        #    f = open('solution_probs_kneser_ney.pkl','w')
        #    cPickle.dump(probs,f)
        #    f.close()

        f = open('solution_probs_kneser_ney.pkl','r')
        sol_probs = cPickle.load(f)
        f.close()

        if np.sum((sol_probs - probs)**2) < 1e-8:
            print "[RÉUSSI] Calcul de probabilités"
        else:
            print "[ÉCHEC] Calcul de probabilités"
            print "n-gramme",test_mot_1,": log-prob attendue =",sol_probs[0],', log-prob obtenue =',probs[0]
            print "n-gramme",test_mot_2,": log-prob attendue =",sol_probs[1],', log-prob obtenue =',probs[1]
            print "n-gramme",test_mot_3,": log-prob attendue =",sol_probs[2],', log-prob obtenue =',probs[2]
            print "n-gramme",test_mot_fin,": log-prob attendue =",sol_probs[3],', log-prob obtenue =',probs[3]
            print "phrase",test_phrase,": log-prob attendue =",sol_probs[4],', log-prob obtenue =',probs[4]

        print "Perplexité sur entraînement :",perplexite(sol_corpus_phrases_entrainement,kneser_ney)
        print "Perplexité sur validation :",perplexite(sol_corpus_phrases_validation,kneser_ney)
        print "Perplexité sur test :",perplexite(sol_corpus_phrases_test,kneser_ney)
        print ""        

        # Test sommation à 1
        def test_somme_1(test_ngramme,modele,vocabulaire):
            s = 0.
            for m in sol_vocabulaire:
                s += math.exp(modele.log_probabilite_mot(m,test_ngramme[-2],test_ngramme[-3]))
            print s
            
        #test_somme_1(test_mot_1,  kneser_ney,sol_vocabulaire)
        #test_somme_1(test_mot_2,  kneser_ney,sol_vocabulaire)
        #test_somme_1(test_mot_3,  kneser_ney,sol_vocabulaire)
        #test_somme_1(test_mot_fin,kneser_ney,sol_vocabulaire)

    else:
        print "Phrase :", phrase
        phrase = solution_ngramme2.remplacement_unk(phrase,vocabulaire)
        print "Phrase avec <unk> :", phrase

        # Modèle avec lissage de add-delta
        katz = solution_ngramme2.TrigrammeRepliKatz(0.001,vocabulaire)
        katz.entrainement(corpus_phrases_entrainement)
        lp = katz.log_probabilite_phrase(phrase)
        print "Log-probabilité (repli de Katz) :",lp

        # Modèle avec lissage par interpolation
        kneser_ney = solution_ngramme2.TrigrammeKneserNey(0.9)
        kneser_ney.entrainement(corpus_phrases_entrainement)
        lp = kneser_ney.log_probabilite_phrase(phrase)
        print "Log-probabilité (Kneser Ney) :",lp

if __name__ == "__main__":
    main()
