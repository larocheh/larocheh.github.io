# -*- coding: utf-8 -*-

import numpy as np

################
# Solution cky #
################

def cky(phrase, non_terminaux, terminaux, productions, symbole_depart):
    """
    Retourne une illustration (``str``) de l'arbre syntaxique d'une phrase, pour 
    un grammaire hors contexte donnée. 

    L'arbre doit suivre la "bracketed notation". Si la phrase ne fait
    pas partie de la grammaire, retourne alors une chaîne vide ``''``.
    
    Args:
      phrase (list):          mots d'une phrase à analyser
      non_terminaux (set):    ensemble des symboles non-terminaux
      terminaux (set):        ensemble des symboles terminaux
      productions (list):     règles de production sous la forme d'une liste de paires (exemple: ``('A',['B','C'])``)
      symbole_depart (str)    symbole de départ de la grammaire

    Returns:
      chaîne de caractère (str) illustrant l'arbre syntaxique

    """

    # À implémenter
    
    return "À IMPLÉMENTER"

