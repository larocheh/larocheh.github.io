# -*- coding: utf-8 -*-

import numpy as np
import math
import sys
import cPickle

##############################
# Execution en tant que script
##############################
def main():
    usage = """
Usage: python classification.py 

Une comparaison sera faite avec un cas pour lequel les résultats
attendus sont connus. 
"""

    if len(sys.argv) != 1:
        print usage
        return None


    # Obtenir les données et divisier en entraînement, validation et test
    from nltk.corpus import movie_reviews
    documents = [(list(movie_reviews.words(fileid)), category)
                 for category in movie_reviews.categories()
                 for fileid in movie_reviews.fileids(category)]

    np.random.seed(1234)
    np.random.shuffle(documents)

    corpus_entrainement_docs = []
    corpus_entrainement_classes = []
    corpus_validation_docs = []
    corpus_validation_classes = []
    corpus_test_docs = []
    corpus_test_classes = []
    map_class_to_id = {'neg':0,'pos':1}
    for i in range(len(documents)):
        doc = documents[i][0]
        classe = map_class_to_id[documents[i][1]]
        if i%8 < 6:
            corpus_entrainement_docs.append(doc)
            corpus_entrainement_classes.append(classe)
        elif i%8 < 7:
            corpus_validation_docs.append(doc)
            corpus_validation_classes.append(classe)
        else:
            corpus_test_docs.append(doc)
            corpus_test_classes.append(classe)
    
    import solution_classification

    # Obtention du vocabulaire
    vocabulaire = solution_classification.extraire_vocabulaire_ordonne(corpus_entrainement_docs, 30) 

    f = open('solution_vocabulaire_classification.pkl','r')
    sol_vocabulaire = cPickle.load(f)
    f.close()

    if set(sol_vocabulaire.keys()) == set(vocabulaire.keys()) \
            and set(sol_vocabulaire.values()) == set(vocabulaire.values()):
        print "[RÉUSSI] ",
    else:
        print "[ÉCHEC] ",
    print "Extraction de vocabulaire"

    corpus_entrainement_docs = [ solution_classification.remplacement_unk(doc, sol_vocabulaire) for doc in corpus_entrainement_docs ]
    corpus_validation_docs   = [ solution_classification.remplacement_unk(doc, sol_vocabulaire) for doc in corpus_validation_docs ]

        
    f = open('solution_unk_train.pkl','r')
    sol_corpus_entrainement_docs = cPickle.load(f)
    f.close()

    f = open('solution_unk_valid.pkl','r')
    sol_corpus_validation_docs = cPickle.load(f)
    f.close()
    
    if corpus_validation_docs == sol_corpus_validation_docs:
        print "[RÉUSSI] ",
    else:
        print "[ÉCHEC] ",
    print "Remplacement par <unk>"
    
    # Évaluation de l'extration de sac de mots
    bow = solution_classification.sac_de_mots(sol_corpus_entrainement_docs[0],sol_vocabulaire)
    
    f = open('solution_sac_de_mots.pkl','r')
    sol_bow = cPickle.load(f)
    f.close()

    if np.mean(np.abs(bow - sol_bow)) < 1e-8:
        print "[RÉUSSI] ",
    else:
        print "[ÉCHEC] ",
    print "Calcul sac de mots"

    # Évaluation du calcul de la pondération idf
    idf = solution_classification.idf(sol_corpus_entrainement_docs,sol_vocabulaire)
    
    f = open('solution_idf.pkl','r')
    sol_idf = cPickle.load(f)
    f.close()

    if np.mean(np.abs(idf - sol_idf)) < 1e-8:
        print "[RÉUSSI] ",
    else:
        print "[ÉCHEC] ",
    print "Calcul de la pondération idf"


    # Évaluation du calcul de la représentation tf-idf
    tfidf = solution_classification.tfidf(sol_corpus_entrainement_docs[0],sol_vocabulaire, sol_idf)
    
    f = open('solution_tfidf.pkl','r')
    sol_tfidf = cPickle.load(f)
    f.close()

    if np.mean(np.abs(tfidf - sol_tfidf)) < 1e-8:
        print "[RÉUSSI] ",
    else:
        print "[ÉCHEC] ",
    print "Calcul de la représentation tfidf"

    f = open('solution_tous_sac_de_mots.pkl','r')
    entrainement_sac_de_mots, validation_sac_de_mots, test_sac_de_mots = cPickle.load(f)
    f.close()
    
    # Évaluation de l'entraînement
    classif = solution_classification.Classifieur(entrainement_sac_de_mots.shape[1], 0.001)
    print "Exécution de l'entraînement avec représentation sac de mots..."
    classif.entrainement(entrainement_sac_de_mots, corpus_entrainement_classes, 3)
    entrainement_pred = np.array([ classif.prediction(x) for x in entrainement_sac_de_mots])
    validation_pred =   np.array([ classif.prediction(x) for x in validation_sac_de_mots])
    test_pred =         np.array([ classif.prediction(x) for x in test_sac_de_mots])

    print "Performance (erreur) avec représentation sac de mots"
    print "  Entraînement:", np.mean(np.abs(entrainement_pred - corpus_entrainement_classes))
    print "  Validation:",   np.mean(np.abs(validation_pred   - corpus_validation_classes))
    print "  Test:",         np.mean(np.abs(test_pred         - corpus_test_classes))

    f = open('solution_tous_tfidf.pkl','r')
    entrainement_tfidf, validation_tfidf, test_tfidf = cPickle.load(f)
    f.close()

    classif = solution_classification.Classifieur(entrainement_tfidf.shape[1], 0.001)
    print "Exécution de l'entraînement avec représentation tf-idf..."
    classif.entrainement(entrainement_tfidf, corpus_entrainement_classes, 3)
    entrainement_pred = np.array([ classif.prediction(x) for x in entrainement_tfidf])
    validation_pred =   np.array([ classif.prediction(x) for x in validation_tfidf])
    test_pred =         np.array([ classif.prediction(x) for x in test_tfidf])

    print "Performance (erreur) avec représentation tf-idf"
    print "  Entraînement:", np.mean(np.abs(entrainement_pred - corpus_entrainement_classes))
    print "  Validation:",   np.mean(np.abs(validation_pred   - corpus_validation_classes))
    print "  Test:",         np.mean(np.abs(test_pred         - corpus_test_classes))

    f = open('solution_validation_pred.pkl','r')
    sol_validation_pred = cPickle.load(f)
    f.close()

    if np.mean(np.abs(validation_pred-sol_validation_pred)) < 1e-8:
        print "[RÉUSSI] ",
    else:
        print "[ÉCHEC] ",
    print "Entraînement et prédiction"

if __name__ == "__main__":
    main()
