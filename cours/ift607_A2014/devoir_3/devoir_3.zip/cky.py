# -*- coding: utf-8 -*-

import numpy as np
import sys
import cPickle

##############################
# Execution en tant que script
##############################
def main():
    usage = """
Usage: python cky.py [mot1 mot2 ...]

Si aucun argument n'est donné, une comparaison
sera faite avec un cas pour lequel les résultats
attendus sont connus. 

Optionnellement, une phrase, spécifiée mot à mot,
peut être fournie. Le programme retournera alors
son arbre syntaxique. Si la phrase ne fait pas partie 
de la grammaire, une chaîne vide ('') doit être retournée.
"""

    if len(sys.argv) == 1:
        eval = True
        phrase = "I prefer a morning flight".split(' ')
    elif len(sys.argv) == 2 and sys.argv[1] == "-h":
        print usage
        return None
    else:
        phrase = sys.argv[1:]
        eval = False

    grammar = """
S -> NP VP
NP -> Determiner Nominal | me | I | you | it | Alaska | Baltimore | Los Angeles | Chicago | United | American
Nominal -> Nominal Noun | flight | breeze | trip | morning
VP -> Verb NP | Verb NPPP | Verb PP | is | prefer | like | need | want | fly
NPPP -> NP PP
PP -> Preposition NP
Noun -> flight | breeze | trip | morning
Verb -> is | prefer | like | need | want | fly
Pronoun -> me | I | you | it
Determiner -> the | a | an | this | these | that
Preposition -> from | to | on | near
"""

    non_terminaux = set([])
    terminaux = set([])
    productions = []
    symbole_depart = "S"

    for line in grammar.strip().split('\n'):
        A,rhs = line.split('->')
        A = A.strip()
        non_terminaux.add(A)
        for d in rhs.split('|'):
            d = [s.strip() for s in d.strip().split(' ')]
            productions += [(A,d)]
            if len(d) == 1:
                terminaux.add(d[0])

    print "Phrase:",phrase
    import solution_cky
    arbre = solution_cky.cky(phrase, non_terminaux, terminaux, productions, symbole_depart)

    if eval:
        f = open('solution_arbre.pkl','r')
        sol_arbre = cPickle.load(f)
        f.close()

        if arbre == sol_arbre:
            print "[RÉUSSI]", "Arbre syntaxique:",arbre
        else:
            print "[ÉCHEC]", "Arbre syntaxique:",arbre
            print "       ", "Arbre attentdu:  ",sol_arbre

    else:
        print "Arbre syntaxique:",arbre

if __name__ == "__main__":
    main()
