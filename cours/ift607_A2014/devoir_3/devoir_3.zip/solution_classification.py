# -*- coding: utf-8 -*-

import numpy as np
import sys

def extraire_vocabulaire_ordonne(corpus_documents, seuil):
    """
    Retourne un vocabulaire extrait d'un corpus de documents
    en gardant les mots de fréquence plus grande ou égale à ``seuil``.

    IMPORTANT : le vocabulaire doit être ordonné, i.e. qu'il doit explicitement
    associer un entier à chaque mot, de 0 jusqu'au nombre de mots moins 1.
    L'ordre exacte des mots n'est pas important.

    IMPORTANT : le mot spécial ``'<unk>'`` doit être inclu dans le
    vocabulaire et être associé à l'entier 0.
    
    Args:
      corpus_documents (list):  corpus de documents, où chaque document est une paire d'une liste de mots (``str``)
      seuil (int):              seuil sur la fréquence des mots

    Returns:
      vocabulaire (dict) associant chaque mot (``str``) à un entier entre 0 et "nb. de mots" - 1

    """

    voc = {'<unk>':0}

    # À implémenter
    
    return voc


def remplacement_unk(document, vocabulaire):
    """
    Remplace les mots d'un document n'appartenant pas
    au vocabulaire par le mot spécial ``'<unk>'``.

    Args:
      document (list):      document la forme d'une liste de mots (``str``)
      vocabulaire (dict):   ``dict`` associant un mot du vocabulaire à un entier

    Returns:
      document (list) où les mots hors-vocabulaire ont été remplacés par ``'<unk>'``

    """

    # À implémenter
    return document


def sac_de_mots(document, vocabulaire):
    """
    Retourne la représentation en sac de mots (vecteur) d'un document.

    Args:
      document (list):      document sous la forme d'une liste de mots (``str``)
      vocabulaire (dict):   ``dict`` associant un mot du vocabulaire à un entier

    Returns:
      sac de mots (numpy.ndarray) sous la forme d'un vecteur 1D, de taille ``len(vocabulaire)``, 
      contenant les fréquences des mots du document, selon l'ordre précifié par le vocabulaire.

    """

    # À implémenter

    return np.zeros(len(vocabulaire))


def idf(corpus_documents, vocabulaire):
    """
    Retourne le vecteur des valeurs idf, pour tous les mots du vocabulaire, 
    à partir du corpus ``corpus_documents``.

    IMPORTANT: utiliser le logarithme naturel.

    Args:
      corpus_documents (list):  corpus de documents, chacun sous la forme de listes de mots (``str``)
      vocabulaire (set):        ensemble des mots (``str``) du vocabulaire

    Returns:
      poids idf (numpy.ndarray), organisé selon un vecteur 1D, dans l'ordre des entiers associés aux mots du vocabulaire

    """

    # À implémenter

    return np.ones(len(vocabulaire))


def tfidf(document, vocabulaire, idf):
    """
    Retourne la représentation tf-idf d'un document (vecteur), 
    à partir du vocabulaire et de la pondération idf.

    IMPORTANT: pour le "term frequency" tf, utiliser 1+log(fréquence du mot), ou 0 si 
    la fréquence est 0.

    IMPORTANT: utiliser le logarithme naturel.

    Args:
      document (list):      document la forme d'une liste de mots (``str``)
      vocabulaire (dict):   ``dict`` associant un mot du vocabulaire à un entier
      idf (numpy.ndarray):  vecteur des pondérations idf, des mots du vocabulaire

    Returns:
      sac de mots (numpy.ndarray) suivant la représentation tf-idf

    """

    # À implémenter
    
    return np.zeros(len(vocabulaire))


class Classifieur:
    """
    Classifieur binaire basé sur la régression logistique
    """

    def __init__(self, taille_entree, alpha):
        """
        Crée une instance de classifier par régression logistique.

        Args:
          taille_entree (int) :  nb. de dimensions des vecteurs d'entrée
          alpha (float) :        taux d'apprentissage

        """

        self.alpha = alpha

        # Initialisation des paramètres
        self.b = 0
        self.w = np.zeros((taille_entree))

    def entrainement(self, entrees, classes, nb_iterations):
        """
        Exécute ``nb_itertations`` d'entraînement sur l'ensemble
        d'entraînement, formé des entrées dans ``entrees``
        et des classes ``classes``.

        Args:
          entrees (numpy.ndarray):  matrice (tableau 2D) où chaque rangée ``entrees[i]`` correspond au vecteur d'entrée du i-ème exemple
          classes (numpy.ndarray):  vecteur (tableau 1D) où chaque élément ``classes[i]`` correspond à la classe (entier 0 ou 1) du i-ème exemple
          nb_iterations (int):      nombre d'itérations sur l'ensemble d'entraînement à exécuter

        """

        # À implémenter

        pass

    def prediction(self, entree):
        """
        Retourne la classe (0 ou 1) pour le vecteur d'entrée ``entree``.

        Args:
          entree (numpy.ndarray):  vecteur d'entrée (tableau 1D)

        Returns:
          entier (int) 0 ou 1, de la classe prédite pour ``entree``
        """

        # À implémenter

        return 1
