# -*- coding: utf-8 -*-

from __future__ import division

import copy, sys
import numpy as np
import random

from string import Template

def joueur_humain(etat_depart, fct_estEtatFinal, fct_transitions, fct_heuristique):
    etat = etat_depart
    while not fct_estEtatFinal(etat):
        actions_str = '; '.join([ a.__str__() for a in fct_transitions(etat).keys()])
        action = raw_input('Entrer un choix d\'action puis appuyer sur Enter.\nChoisir parmi: {'+actions_str+'}\n')
        while True:
            try:
                exec 'action_ret = ' + action
                fct_transitions(etat)[action_ret]
                break
            except:
                action = raw_input('L\'action n\'est pas valide. Réessayer à nouveau, puis appuyer sur Enter\n')

        etat = fct_transitions(etat)[action_ret]
        yield etat


class Jeu:
    """
    Classe de jeu.
    
    Initialisation à partir de la fonction but,
    fonction transitions et l'état inital du jeu.
    
    La méthode "jouer_partie" simule une partie.
    """
    def __init__(self, etat_depart, fct_estEtatFinal, fct_transitions, fct_heuristique):
        self.etat_initial = etat_depart
        self.but = fct_estEtatFinal
        self.transitions = fct_transitions
        self.heuristique = fct_heuristique

    def jouer_partie(self,joueur):
        etat = self.etat_initial
        nb_coups = 0
        
        print etat
        for etat in joueur(etat, self.but, self.transitions, self.heuristique):
            print etat
            nb_coups += 1
            
        if taquin_estBut(etat):
            print 'Vous avez gagné! ({0} coups)'.format(nb_coups)
        else:
            print 'Vous avez perdu! ({0} coups)'.format(nb_coups)

###########################################
# Etat, transitions et but pour le Taquin #
###########################################
class TaquinEtat:

    def __init__(self, seed=None):
        self.largeur = 3
        self.hauteur = 3
        
        # Initialisation du casse-tête pour validation.
        self.tableau = np.array([ ['6','2','3'],
                                  ['7',' ','8'],
                                  ['4','1','5'] ])
      
        #self.tableau = np.array([ ['6','5','8'],
        #                          ['3','7','1'],
        #                          [' ','4','2'] ])
                                  
        # Construction aléatoire du plateau.
        if seed is not None:
            self._randomize(seed)

    # Création d'un plateau généré aléatoirement.
    def _randomize(self,seed):
        self.tableau = np.array([ ['1','2','3'],
                                  ['4','5','6'],
                                  ['7','8',' '] ])
  
        rnd = random.Random(seed)
        for i in range(1000):
            etat = rnd.choice(taquin_transitions(self).values())
            self.tableau = etat.tableau
    
    # Trouve les coordonnées de la pièce désirée.
    def find(self,case):
        return np.array(np.where(self.tableau == case))
        
    # Calculer le facteur d'ordonnancement pour cet état.
    def calculer_ordre(self):
        txt = "".join(self.tableau.flat)
        txt = txt.replace(' ', '0')
        return 1-(int(txt)/876543210.)
        
        
    def __eq__(self,other):
        return (self.tableau == other.tableau).all()
        
    def __ne__(self,other):
        return not self == other
    
    def __hash__(self):
        return hash("".join(self.tableau.flat))
    
    def __str__(self):
        t = Template("""
   0   1   2
     |   |   
0  $a | $b | $c
     |   |   
  ---+---+---
     |   |   
1  $d | $e | $f
     |   |
  ---+---+---
     |   |   
2  $g | $h | $i
     |   |
""")
        return t.substitute(a=self.tableau[0,0],b=self.tableau[0,1],c=self.tableau[0,2],
                            d=self.tableau[1,0],e=self.tableau[1,1],f=self.tableau[1,2],
                            g=self.tableau[2,0],h=self.tableau[2,1],i=self.tableau[2,2])

        
def taquin_transitions(etat):
    # Déterminer l'emplacement de la case vide
    y,x = etat.find(' ')
    
    # Quatre choix sont théoriquement possibles
    actionsPossibles = [(y-1, x), (y+1, x),
                        (y, x-1), (y, x+1)]

    actions = {}
    for i,j in actionsPossibles:
        # Vérifier si la possible position se trouve à l'intérieur du tableau
        if 0 > i or i >= etat.hauteur or 0 > j or j >= etat.largeur:
            continue

        nouvelEtat = TaquinEtat()
        nouvelEtat.tableau = np.copy(etat.tableau)
        nouvelEtat.tableau[y,x] = nouvelEtat.tableau[i,j]
        nouvelEtat.tableau[i,j] = ' '
        actions[(i[0],j[0])] = nouvelEtat

    return actions

def taquin_transitions_agent(etat):
    return taquin_transitions(etat).values()

def taquin_but():
    but = TaquinEtat()
    but.tableau = np.array([ ['1','2','3'],
                             ['4','5','6'],
                             ['7','8',' '] ])
    
    return but

def taquin_estBut(etat):
    return etat == g_etatFinal

def taquin_heuristique(etat):
    coutHeuristique = 0
    
    for i,pos in enumerate(g_positionsFinales,start=1):
        y1x1 = etat.find(str(i))
        y2x2 = pos
        coutHeuristique += np.sum(np.abs(y2x2-y1x1))
    
    coutHeuristique -= etat.calculer_ordre()
    return max(coutHeuristique, 0)
    
    
####################
# Variable globale #
####################
g_etatFinal = taquin_but()

#Position des cases 1 à 8 inclusivement.
g_positionsFinales = [np.array((0,0)),np.array((0,1)),np.array((0,2)),
                      np.array((1,0)),np.array((1,1)),np.array((1,2)),
                      np.array((2,0)),np.array((2,1))]

g_etats = []
def evaluation():
    import pickle
    #pickle.dump(g_etats, open('taquin_solution.pkl','w'))
    solutionEtats = pickle.load(open('taquin_solution.pkl'))
    
    if len(g_etats) != len(solutionEtats):
        print "Erreur: votre solution comporte {0} coups, alors que vous devriez en avoir {1}!".format(len(g_etats), len(solutionEtats))
        return
    
    for i,e1,e2 in zip(range(len(g_etats)), g_etats, solutionEtats):
        if e1 != e2:
            print "Erreur: l'état #{0} diffère de la solution.".format(i+1)
            print "Votre coup"
            print e1
            print "Solution:"
            print e2
    else:
        print "Votre joueur obtient bien la solution attendue, bravo!"

##############################
# Execution en tant que script
##############################
def main():
    usage = """Usage: python taquin.py joueur [no_partie]

où "joueur" est "agent" ou "humain"
et "no_partie" est un entier quelconque (facultatif)."""

    if not (2 <= len(sys.argv) and len(sys.argv) <= 3):
        print usage
        return None
    elif len(sys.argv) == 2:
        joueur = sys.argv[1]
        no_partie = None
    elif len(sys.argv) == 3:
        joueur = sys.argv[1]
        try:
            no_partie = int(sys.argv[2])
        except ValueError:
            print usage
            return None
        
    if joueur not in ['humain','agent']:
        print usage
        return None

    # Jouer une partie de taquin
    taquin = Jeu(TaquinEtat(no_partie), taquin_estBut, taquin_transitions, taquin_heuristique)
    
    # Pour jouer en tant qu'humain
    if joueur == 'humain':
        taquin.jouer_partie(joueur_humain)
    
    # Pour laisser jouer l'agent intelligent
    if joueur == 'agent':
        import solution_taquin as solution
        
        # S'occupe de créer un générateur une fois la solution trouvée
        def joueurAgent(etat_depart, fct_estEtatFinal, fct_transitions, fct_heuristique):
            global g_etats
            g_etats = solution.joueur_taquin(etat_depart, fct_estEtatFinal, fct_transitions, fct_heuristique)
            return iter(g_etats)
        
        taquin.transitions = taquin_transitions_agent
        taquin.jouer_partie(joueurAgent)
        
        if no_partie is None:
            evaluation()

if __name__ == "__main__":
    main()
