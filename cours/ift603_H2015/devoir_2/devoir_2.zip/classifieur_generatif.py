# -*- coding: utf-8 -*-

from numpy import *
from pylab import *
import cPickle,sys
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint

def save(p, filename):
    """
    Pickles object ``p`` and saves it to file ``filename``.
    """
    f=file(filename,'wb')
    cPickle.dump(p,f,cPickle.HIGHEST_PROTOCOL) 
    f.close()

def load(filename): 
    """
    Loads pickled object in file ``filename``.
    """
    f=file(filename,'rb')
    y=cPickle.load(f)
    f.close()
    return y


##############################
# Execution en tant que script
##############################

def main():
    usage = """Usage: python classifieur_generatif.py"""
    if len(sys.argv) > 1:
        print usage
        return

    import solution_classifieur_generatif as solution

    print "Prétraitement...",
    sys.stdout.flush()
    X,t = solution.pretraitement_donnees('adult.data')
    X_test,t_test = solution.pretraitement_donnees('adult.test')
    print " terminé"

    solution_X, solution_t = load('solution_pretraitement_entrainement.pkl')
    if np.abs(X - solution_X).sum() < 1e-8\
            and np.abs(t - solution_t).sum() < 1e-8:
        print 'Prétraitement (RÉUSSI)'
    else:
        print 'Prétraitement (ERREUR)'

    X, t = solution_X, solution_t
    solution_predictions_entrainement = load('solution_predictions_entrainement.pkl')
    solution_erreurs_entrainement = load('solution_erreurs_entrainement.pkl')
                    
    classifieur_generatif = solution.ClassifieurGeneratif(lamb=0.00001)

    # Entraînement de la régression linéaire
    classifieur_generatif.entrainement(X,t)

    # Prédictions sur les ensembles d'entraînement et de test
    predictions_entrainement = np.array( [classifieur_generatif.prediction(x) for x in X])

    # Calcul des erreurs
    erreurs_entrainement = np.array( [classifieur_generatif.erreur(t_n,p_n) 
                                      for t_n,p_n in zip(t,predictions_entrainement)])

    if np.abs(predictions_entrainement - solution_predictions_entrainement).sum() < 1e-8:
        print 'Entraînement et prédiction (RÉUSSI)'
    else:
        print 'Entraînement et prédiction (ERREUR)'
            
    if np.abs(erreurs_entrainement - solution_erreurs_entrainement).sum() < 1e-8:
        print 'Calcul des erreurs (RÉUSSI)'
    else:
        print 'Calcul des erreurs (ERREUR)'

    predictions_test = np.array( [classifieur_generatif.prediction(x) for x in X_test])
    erreurs_test = np.array( [classifieur_generatif.erreur(t_n,p_n)
                              for t_n,p_n in zip(t_test,predictions_test)])

    print "Erreur d'entraînement :", "%.4f" % erreurs_entrainement.mean()
    print "Erreur de test :", "%.4f" % erreurs_test.mean()
    print ""

if __name__ == "__main__":
    main()
