# -*- coding: utf-8 -*-

#####
# VotreNom (VotreMatricule) .~= À MODIFIER =~.
###

import numpy as np
from pdb import set_trace as dbg #Appeler dbg() pour mettre un breakpoint

def logistic(x):
      return 1. / (1. + np.exp(-x))

class ReseauDeNeurones:
    def __init__(self, alpha, T):
        self.alpha = alpha
        self.T = T

    def initialisation(self, W, w):
        self.W = W
        self.w = w

    def parametres(self):
        return (self.W,self.w)

    def prediction(self, x):
        # Mettre code ici
        pass

    def mise_a_jour(self, x, y):
        # Mettre code ici
        pass

    def entrainement(self, X, Y):
        # Mettre code ici
        pass
