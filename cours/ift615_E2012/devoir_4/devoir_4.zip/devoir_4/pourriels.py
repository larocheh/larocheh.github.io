# -*- coding: utf-8 -*-

from numpy import *
import pickle,sys
from pdb import set_trace as dbg

def save(p, filename):
    """
    Pickles object ``p`` and saves it to file ``filename``.
    """
    f=file(filename,'wb')
    pickle.dump(p,f,pickle.HIGHEST_PROTOCOL) 
    f.close()

def load(filename):
    """
    Loads pickled object in file ``filename``.
    """
    f=file(filename,'rb')
    y=pickle.load(f)
    f.close()
    return y
    
    
def pretraiter(corpus,V,sol):
    corpusTraite = []
    for d,c in corpus:
        corpusTraite.append((sol.pretraiter(d,V),c))

    return corpusTraite


##############################
# Execution en tant que script
##############################

def main():
    usage = """Usage: python pourriels.py"""

    if len(sys.argv) != 1:
        print usage
        return
        
    import solution_pourriels as sol

    delta = 1
    seuilFreq = 5
    SPAM,HAM = 0,1
    classes = [SPAM,HAM]

    train = load('train_pourriels.pkl')
    test = load('test_pourriels.pkl')

    #Création du vocabulaire
    print "Création du vocabulaire"
    V = sol.creerVocabulaire([d[0] for d in train], seuil=seuilFreq)

    #Prétraitement des corpus
    print "Prétraitement des corpus"
    trainCorpus = pretraiter(train, V, sol)
    testCorpus = pretraiter(test, V, sol)

    print "Entraînement et prédiction"
    #Entraînement
    P = sol.Probabilite()
    P.vocabulaire = V
    sol.entrainer(trainCorpus, P)
    
    #Prédiction
    # Calcul des erreurs de classification
    erreur_train = mean([ y != sol.predire(x,P,classes, delta=delta)[0] for x,y in trainCorpus])
    print 'Erreur de classification sur ensemble d\'entraînement ('+str(len(trainCorpus))+ ' items): %.4f' % (erreur_train*100) + '%'
    
    erreur_test = mean([ y != sol.predire(x,P,classes, delta=delta)[0] for x,y in testCorpus])
    print 'Erreur de classification sur ensemble de test ('+str(len(testCorpus))+ ' items): %.4f' % (erreur_test*100) + '%'

    
    #########
    # Tests #
    #########

    # Réduire la taille du corpus pour les test
    train = train[:10] + train[-10:]
    trainCorpus = trainCorpus[:10] + trainCorpus[-10:]

    import cPickle
    f = open('pourriels_solution_attendue.pkl')
    res_V,res_pretraiter,res_prob,res_nbMotsParClasse, res_nbDocsParClasse, res_freqWC = cPickle.load(f)
    
    print "Test de creerVocabulaire",
    testing_V = sol.creerVocabulaire([d[0] for d in train],seuil=10)    
    if len(res_V-testing_V) == 0 and len(testing_V-res_V) == 0:
        print '(RÉUSSI)'
    else:
        print '(ERREUR)'
    
    print "Test de pretraiter",
    testing_pretraiter = sol.pretraiter(train[0][0],res_V)
    if len(testing_pretraiter) == len(res_pretraiter)\
            and all([aaa == bbb for aaa,bbb in zip(res_pretraiter,testing_pretraiter)]):
        print '(RÉUSSI)'
    else:
        print '(ERREUR)'
    
    print "Test de entrainer",
    testing_P = sol.Probabilite()
    testing_P.vocabulaire = res_V
    sol.entrainer(trainCorpus, testing_P)

    def compare_dict(a,b):
        if len(set(a.keys())-set(b.keys())) != 0: return False
        if len(set(b.keys())-set(a.keys())) != 0: return False
        for k in a.keys():
            if a[k] != b[k]:
                print a[k],b[k]
                return False
        return True

    if compare_dict(testing_P.nbMotsParClasse,res_nbMotsParClasse)\
            and compare_dict(testing_P.nbDocsParClasse,res_nbDocsParClasse)\
            and compare_dict(testing_P.freqWC,res_freqWC):
        print '(RÉUSSI)'
    else:
        print '(ERREUR)'
    
    print "Test de predire",
    res_P = sol.Probabilite()
    from collections import defaultdict
    for k,v in res_nbMotsParClasse.items(): res_P.nbMotsParClasse[k] = v
    for k,v in res_nbDocsParClasse.items(): res_P.nbDocsParClasse[k] = v
    for k,v in res_freqWC.items(): res_P.freqWC[k] = v
    res_P.vocabulaire = res_V

    testing_prob = sol.predire(trainCorpus[0][0],res_P,classes, delta=delta)
    if res_prob[0] == testing_prob[0] and ((res_prob[1] - testing_prob[1])**2 < 1e-10):
        print '(RÉUSSI)'
    else:
        print '(ERREUR)'


if __name__ == "__main__":
    main()
