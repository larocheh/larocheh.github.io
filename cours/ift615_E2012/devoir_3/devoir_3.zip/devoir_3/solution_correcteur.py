# -*- coding: utf-8 -*-

#####
# VotreNom (VotreMatricule) .~= À MODIFIER =~.
###

import pdb #Utiliser pdb.set_trace() pour faire un break dans votre code.
import numpy as np

#######################
# Solution correcteur #
#######################

#####
# corrige: Fonction qui retourne la correction d'un mot donné.
#
# mot: Mot à corriger (str).
#
# p_init: Probabilités initiales de l'état caché à la première position (tableau Numpy 1D de float).
#
# p_transition: Modèle de transition (tableau Numpy 2D de float).
#
# p_observation: Modèle d'observation (tableau Numpy 2D de float).
#
# int_to_letters: Liste énumérant toutes les lettres possibles (liste de str).
#
# letters_to_int: dictionnaire qui donne la position de chaque lettre dans la liste int_to_letters (dict).
#
# retour: Un tuple contenant le mot corrigé et la probabilité p(mot, mot corrigé).
### 
def corrige(mot,p_init,p_transition,p_observation,int_to_letters,letters_to_int):
    return mot,0
