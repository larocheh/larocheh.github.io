# -*- coding: utf-8 -*-

import copy, sys, re, time, pickle
import numpy as np

# Associe un entier à chaque letter
int_to_letters = ['a','b','c','d','e','f','g',
                  'h','i','j','k','l','m','n',
                  'o','p','q','r','s','t','u',
                  'v','w','x','y','z']
letters_to_int = {}
for i,l in enumerate(int_to_letters):
    letters_to_int[l] = i

n_letters = len(letters_to_int)

# Identifie les voisins de chaque lettre sur mon clavier mac
# (putain que ça a été long à écrire!!)
voisins_claviers = {'a':['q','w','s','z'],
                    'b':['v','g','h','n'],
                    'c':['x','d','f','v'],
                    'd':['s','e','r','f','c','x'],
                    'e':['w','s','d','r'],
                    'f':['d','r','t','g','v','c'],
                    'g':['f','t','y','h','b','v'],
                    'h':['g','y','u','j','n','b'],
                    'i':['u','j','k','o'],
                    'j':['h','u','i','k','m','n'],
                    'k':['j','i','o','l','m'],
                    'l':['k','o','p'],
                    'm':['n','j','k'],
                    'n':['b','h','j','m'],
                    'o':['i','k','l','p'],
                    'p':['o','l'],
                    'q':['a','w'],
                    'r':['e','d','f','t'],
                    's':['a','w','e','d','x','z'],
                    't':['r','f','g','y'],
                    'u':['y','h','j','i'],
                    'v':['c','f','g','b'],
                    'w':['q','a','s','e'],
                    'x':['z','s','d','c'],
                    'y':['t','g','h','u'],
                    'z':['a','s','x']}
                        
# Modèle d'observation
p_observation = np.zeros((n_letters,n_letters))
prob_correct = 0.9
for i in range(n_letters):
    l = int_to_letters[i]
    p_observation[i,i] = prob_correct
    voisins = voisins_claviers[l]
    for v in voisins:
        p_observation[letters_to_int[v],i] = (1.-prob_correct)/len(voisins)

p_observation /= p_observation.sum(axis=0).reshape((1,-1))

# Modèle de transition
f = open('p_transition.pkl')
p_transition = pickle.load(f)
f.close()

# Charger les probabilités initiales
f = open('p_init.pkl')
p_init = pickle.load(f)
f.close()

##############################
# Execution en tant que script
##############################
def main():
    usage = """Usage: python correcteur.py [mot]

où "mot" est un mot à corriger (facultatif).
Si aucun mot n'est spécifié, le correcteur
sera utilisé sur une liste prédéfinie de 
mots et sera comparé avec la réponse attendue.
Une comparaison sera également faite avec la
solution de l'exemple sur la séquence de bits '0100' 
vu dans le cours.
"""

    if not (len(sys.argv) == 1 or len(sys.argv) == 2):
        print usage
        return

    from solution_correcteur import corrige
    
    if len(sys.argv) == 2:
        mot = sys.argv[1]
        mot_corrige, prob = corrige(mot,p_init,p_transition,p_observation,int_to_letters,letters_to_int)
        print 'Correction:',mot_corrige+', p(mot_corrige,mot)='+str(prob)

    else:
    
        mots = ['bonjojr','imtelligwmce','infprmqtiwue','poiwwon','trzvajl','pfpgrqmme']
        reponses_attendues = [ ('bonjour', 1.20818392722e-09),
                               ('intelligence', 4.67443191136e-18),
                               ('informatique', 3.25462496877e-19),
                               ('poisson', 8.1786639759e-11),
                               ('travail', 1.72119029099e-11),
                               ('programme', 2.28282587957e-15) ]

        reussi = True
        for m,r in zip(mots,reponses_attendues):
            mot_corrige, prob = corrige(m,p_init,p_transition,p_observation,int_to_letters,letters_to_int)
            mot_corrige_rep, prob_rep = r
            print 'Mot:',m
            print 'Correction:',mot_corrige+', p(mot_corrige,mot)='+str(prob)
            print 'Solution attendue:',mot_corrige_rep+', p(mot_corrige,mot)='+str(prob_rep)
            if mot_corrige != mot_corrige_rep or np.abs(prob-prob_rep)/prob_rep > 1e-6:
                print 'MAUVAISE RÉPONSE'
                reussi = False
            print ''

        # Test sur exemple du cours
        p_observation_bits = np.array([[0.9,0.2],[0.1,0.8]])
        p_transition_bits = np.array([[0.3,0.4],[0.7,0.6]])
        p_init_bits = np.array([0.5,0.5])
        sequence_bits = '0100'
        bits_to_int = {'0':0,'1':1}
        int_to_bits = ['0','1']

        mot_corrige, prob = corrige(sequence_bits,p_init_bits,p_transition_bits,p_observation_bits,int_to_bits,bits_to_int)
        mot_corrige_rep = '0100'
        prob_rep = 0.0244944

        print 'Sequence bits:',sequence_bits
        print 'Correction:',mot_corrige+', p(mot_corrige,mot)='+str(prob)
        print 'Solution attendue:',mot_corrige_rep+', p(mot_corrige,mot)='+str(prob_rep)        
        if mot_corrige != mot_corrige_rep or np.abs(prob-prob_rep)/prob_rep > 1e-6:
            print 'MAUVAISE RÉPONSE'
            reussi = False
        print ''

        if reussi:
            print 'Bravo, toutes les solutions trouvées sont bonnes!'
        else:
            print 'Les solutions trouvées ne sont pas toutes bonnes'
            
if __name__ == "__main__":
    main()
