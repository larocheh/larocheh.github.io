# -*- coding: utf-8 -*-

import copy, sys, re, time, pickle
import numpy as np

class Jeu:
    """
    Classe de jeu.
    
    Initialisation à partir de la fonction but,
    fonction transitions et l'état inital du jeu.
    
    La méthode "jouer_partie" simule une partie.
    """
    def __init__(self, etat_depart, fct_but, fct_transitions, fct_heuristique):
        self.etat_initial = etat_depart
        self.but = fct_but
        self.transitions = fct_transitions
        self.heuristique = fct_heuristique

    def jouer_partie(self,joueur):
        etat = self.etat_initial
        
        print etat
        for etat in joueur(etat, self.but, self.transitions, self.heuristique):
            pass #Les états intermédiaires importent peu

        print etat #Affiche la grille complétée
        if self.but(etat):
            print 'Vous avez gagné!'
        else:
            print 'Vous avez perdu!'

###################################
# Constraint Satisfaction Problem #
###################################
g_evaluation = []
class CSP:
    def __init__(self, variables, domaines, contraintes):
        self.variables = variables
        self.domaines = domaines
        self.contraintes = contraintes
        
    def arcs(self):
        return [(Xi, Xj) for Xi in self.contraintes for Xj in self.contraintes[Xi]]
        
    def copy(self):
        g_evaluation.append(self.domaines)
        return CSP(self.variables, copy.deepcopy(self.domaines), self.contraintes)


###################################
# Etat, but et csp pour le Sudoku #
###################################
class SudokuEtat:

    def __init__(self, tableau=None):
        self.tableau = tableau
        if self.tableau is None:
            self.tableau = np.zeros([9,9],dtype='S1')
            self.tableau[:] = ' '

    # Trouve les coordonnées de la pièce désirée.
    def find(self,case):
        return np.array(np.where(self.tableau == case))
    
    # Trouve les coordonnées des cases sauf celle de la pièce désirée.
    def findNot(self,case):
        return np.array(np.where(self.tableau != case))
        
    # Place une valeur dans la grille à la position donnée.
    def placer(self, coordonnee, valeur):
        etat = SudokuEtat()
        etat.tableau = np.copy(self.tableau)
        etat.tableau[coordonnee] = valeur
        return etat

    def __eq__(self,other):
        return (self.tableau == other.tableau).all()
        
    def __ne__(self,other):
        return not self == other
    
    def __hash__(self):
        return hash("".join(self.tableau.flat))
    
    def __str__(self):
        t = """
  012 345 678

0 {0}{1}{2}|{3}{4}{5}|{6}{7}{8}
1 {9}{10}{11}|{12}{13}{14}|{15}{16}{17}
2 {18}{19}{20}|{21}{22}{23}|{24}{25}{26}
  ---+---+---
3 {27}{28}{29}|{30}{31}{32}|{33}{34}{35}
4 {36}{37}{38}|{39}{40}{41}|{42}{43}{44}
5 {45}{46}{47}|{48}{49}{50}|{51}{52}{53}
  ---+---+---
6 {54}{55}{56}|{57}{58}{59}|{60}{61}{62}
7 {63}{64}{65}|{66}{67}{68}|{69}{70}{71}
8 {72}{73}{74}|{75}{76}{77}|{78}{79}{80}
"""
        return t.format(*self.tableau.flat)

class SudokuUtil:
    @staticmethod
    def generer(seed):
        if seed is None:
            # Initialisation du Sudoku pour validation (Difficile).
            txt = "     4  7" + \
                  " 1       " + \
                  "796 3    " + \
                  "4    2   " + \
                  " 3  6  5 " + \
                  "   7    1" + \
                  "    5 932" + \
                  "       6 " + \
                  "2  8     "
                  
        elif seed == 1:
            #Sudoku - Débutant
            txt = "  74  1  " + \
                  " 4 8   2 " + \
                  " 8  29 7 " + \
                  "  5    41" + \
                  "  2   6  " + \
                  "93    5  " + \
                  " 2 75  1 " + \
                  " 5   6 3 " + \
                  "  8  34  "
        elif seed == 2:
            #Sudoku - Moyen
            txt = "  53     " + \
                  "8      2 " + \
                  " 7  1 5  " + \
                  "4    53  " + \
                  " 1  7   6" + \
                  "  32   8 " + \
                  " 6 5    9" + \
                  "  4    3 " + \
                  "     97  "
        elif seed == 3:
            #Sudoku - Très difficile
            txt = "85   24  " + \
                  "72      9" + \
                  "  4      " + \
                  "   1 7  2" + \
                  "3 5   9  " + \
                  " 4       " + \
                  "    8  7 " + \
                  " 17      " + \
                  "    36 4 "
        else:
            #Sudoku - Très débutant
            txt = "3 1286 75" + \
                  "47 359 8 " + \
                  "86 174392" + \
                  "6 7823 1 " + \
                  "238 41567" + \
                  "9 47  238" + \
                  "7 349 156" + \
                  "1 65 7 49" + \
                  "54  18723"

        return SudokuEtat(SudokuUtil.convertir(txt))

    @staticmethod
    def convertir(txt):
        return np.array(list(txt),dtype="S1").reshape(9,9)

    @staticmethod
    def csp2etat(csp, assignations={}):
        etat = SudokuEtat()
        for pos,d in csp.domaines.items():
            if len(d) == 1:
                etat = etat.placer(pos, d[0])
                
        for pos,v in assignations.items():
            etat = etat.placer(pos, v)
            
        return etat
        
def tousUniques(sequence):
    sequence = sequence.flatten()
    for i,valeur in enumerate(sequence):
        if valeur in sequence[i+1:]:
            return False

    return True

def sudoku_but(etat):
    if etat.find(' ').shape[1] != 0:
        return False

    estTermine = True
    for i in range(9):
        estTermine &= tousUniques(etat.tableau[i,:])
        estTermine &= tousUniques(etat.tableau[:,i])
        subY,subX = i//9, (i%3)*3
        estTermine &= tousUniques(etat.tableau[subY:subY+3,subX:subX+3])

    return estTermine

def sudoku_solution(etat, noPartie):
    if noPartie is None:
        return "".join(map(str, etat.tableau.flatten())) == "382514697514976823796238514451392786837461259629785341148657932975123468263849175"
        
    if noPartie == 1:
        return "".join(map(str, etat.tableau.flatten())) == "297435168143867925586129374865392741712548693934671582329754816451986237678213459"
    
    if noPartie == 2:
        return "".join(map(str, etat.tableau.flatten())) == "145327698839654127672918543496185372218473956753296481367542819984761235521839764"
    
    if noPartie == 3:
        return "".join(map(str, etat.tableau.flatten())) == "859612437723854169164379528986147352375268914241593786432981675617425893598736241"
        
    return "".join(map(str, etat.tableau.flatten())) == "391286475472359681865174392657823914238941567914765238783492156126537849549618723"

def creerCSP(etat):
    #Les variables représentent les cases vides
    variables = zip(*etat.find(' '))
    
    #Le domaine des cases libres est toutes les possibilités [1-9]
    domaines = {}
    for V in variables:
        domaines[V] = [str(i) for i in range(1,10)]
        
    #Pour les cases déjà remplies, le domaine est seulement la valeur de la case
    for V in zip(*etat.findNot(' ')):
        domaines[V] = [etat.tableau[V],]
        variables.append(V)

    #Les contraintes sont ajoutés pour toutes les variables associées.
    contraintes = {}
    for V in variables:
        y,x = V
        contraintes[V] = []
        contraintes[V] += [(y,i) for i in range(9)] #Contraintes de ligne
        contraintes[V] += [(i,x) for i in range(9)] #Contraintes de colonne
        
        blocY, blocX = (y//3)*3, (x//3)*3
        contraintes[V] += [(blocY+i//3, blocX+i%3) for i in range(9)] #Contraintes de bloc
        
        contraintes[V] = set(contraintes[V]) #Les contraintes doivent être uniques
        contraintes[V].remove(V) #Aucune contrainte avec soi-même
        
    return CSP(variables, domaines, contraintes)

            
###########################
# Joueur(s) alternatif(s) #
###########################
regex_action = r'^\(([0-8]),([0-8])\)\s*=\s*([1-9])$'

def est_coup_legal(X,v, etat):
    estLegal = True
    estLegal &= v not in etat.tableau[X[0],:] #Contraintes de ligne
    estLegal &= v not in etat.tableau[:,X[1]] #Contraintes de colonnes
    blocY,blocX = (X[0]//3)*3, (X[1]//3)*3 
    estLegal &= v not in etat.tableau[blocY:blocY+3, blocX:blocX+3] #Contraintes de blocs
    return estLegal

def joueur_humain(etat_depart, fct_but, fct_transitions, fct_heuristique):
    etat = etat_depart
    while not fct_but(etat):
        action = raw_input('Entrer une coordonnée et une valeur. (ex. (Y,X) = V)\n')
        while True:
            try:
                y,x,v = re.match(regex_action, action).groups()
                y,x = int(y),int(x)

                if (y,x) not in fct_transitions(etat):
                    raise NamedError('Action invalide!')

                if not est_coup_legal((y,x), v, etat):
                    print "Coup non légal!"
                    raise NamedError('Coup non légal!')
                    
                break
            except:
                action = raw_input('L\'action n\'est pas valide. Réessayer à nouveau, puis appuyer sur Enter\n')

        etat = etat.placer((y,x), v)
        yield etat

##############################
# Execution en tant que script
##############################
def main():
    usage = """Usage: python sudoku.py joueur [no_partie]

où "joueur" est "humain" ou "agent"
et "no_partie" est un entier entre [0-3] (facultatif).
    -> 0: Très débutant
    -> 1: Débutant
    -> 2: Intermédiaire
    -> 3: Très difficile
    -> Défaut: Difficile + Évaluation"""

    if not (len(sys.argv) == 2 or len(sys.argv) == 3):
        print usage
        return

    joueur = sys.argv[1]
    no_partie = None
    
    if len(sys.argv) == 3:
        try:
            no_partie = int(sys.argv[2])
        except ValueError:
            print usage
            return
        
    if joueur not in ['humain','agent']:
        print usage
        return

    sudokuEtat = SudokuUtil.generer(no_partie)
        
    # Jouer une partie de sudoku
    sudoku = Jeu(sudokuEtat, sudoku_but, None, None)
    
    # Pour jouer en tant qu'humain
    if joueur == 'humain':
        sudoku.jouer_partie(joueur_humain)
    
    # Pour laisser jouer l'agent intelligent
    if joueur == 'agent':
        import solution_sudoku as solution
        
        # Coquille simulant un joueur à partir des assignations retournées par backtracking_search
        def joueurAgent(etat_depart, fct_estEtatFinal, fct_transitions, fct_heuristique):
            assignations = solution.backtracking_search(creerCSP(etat_depart))
            
            #Générateur d'états à partir des assignations
            def iterEtats():
                etat = etat_depart
                for pos,v in assignations.items():
                    etat = etat.placer(pos,v)
                    yield etat

            return iterEtats()

        tempsDebut = time.time()
        sudoku.jouer_partie(joueurAgent)
            
        ##### Évaluation #####
        print "\n#########\n# Infos #\n#########"
        
        nbCasesVides = len(sudokuEtat.find(' ')[0])
        nbCoups = len(g_evaluation)
        taillesDomaine = np.array(map(lambda e:sum(map(len, dict(e).values())), g_evaluation))
        nbBacktracks = nbCoups - nbCasesVides
            
        print "Nb. cases vides: {0}".format(nbCasesVides)
        print "Nb. coups: {0}".format(nbCoups)

        if nbCoups == 0:
            print "* Attention, l'objet CSP doit être passé à AC3 par copie! -> csp.copy() <-"
            return

        print "Nb. backtracks: {0}".format(nbBacktracks)
        print "Temps écoulé: %0.2f sec." % (time.time()-tempsDebut)        

        solutionTrouve = SudokuUtil.csp2etat(CSP([],dict(g_evaluation[-1]),[]))
        if not sudoku_but(solutionTrouve):
            print "* La solution trouvée n'est pas valide!"
            
        if not sudoku_solution(solutionTrouve, no_partie):
            print "* La solution trouvée n'est pas la bonne!"

        if no_partie is None:
            print "\n###############\n# Validations #\n###############"
            #sol_nbCoups = len(g_evaluation)
            #sol_nbBacktracks = sol_nbCoups - len(sudokuEtat.find(' ')[0])
            #pickle.dump((sol_nbCoups, sol_nbBacktracks), open('sudoku_solution.pkl', 'w'))
            
            sol_nbCoups, sol_nbBacktracks = pickle.load(open('sudoku_solution.pkl'))
            
            print "Nb. coups: {0} vs. {1}".format(nbCoups,sol_nbCoups)
            if sol_nbCoups < nbCoups:
                print "* Votre nombre d'essais ({0}) peut être amélioré (Objectif: {1})!".format(nbBacktracks,sol_nbBacktracks)

            print "Nb. backtracks: {0} vs. {1}".format(nbBacktracks,sol_nbBacktracks)
            if sol_nbBacktracks < nbBacktracks:
                print "* Votre nombre de backtracks ({0}) peut être réduit (Objectif: {1})!".format(nbBacktracks,sol_nbBacktracks)


if __name__ == "__main__":
    main()
